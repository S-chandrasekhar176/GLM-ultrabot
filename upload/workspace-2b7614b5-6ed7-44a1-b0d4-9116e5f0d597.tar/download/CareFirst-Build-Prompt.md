# CareFirst Home Nursing Services — Complete Build Prompt

> **Copy everything below this line and paste into a new Super Z session. It will produce the exact same production-ready website.**

---

Build me a production-ready YMYL nursing homecare website called **"CareFirst Home Nursing Services"** for Hyderabad using **Next.js 16 (App Router), TypeScript, Tailwind CSS v4, shadcn/ui, and Prisma + SQLite**. This is a single-page application with client-side routing (no actual page navigation — all views render from `/` route using `useState`).

## PROJECT SETUP

- Next.js 16 with App Router, `output: "standalone"` in next.config.ts, `ignoreBuildErrors: true`, `reactStrictMode: false`
- Prisma with SQLite (`file:./db/custom.db`)
- Tailwind CSS v4 with `tw-animate-css`
- Google Fonts: Inter (body text)
- All pages render from `src/app/page.tsx` — use `currentView` state ("home" or "service") and `activeService` state for routing
- Install shadcn/ui components: button, sheet, toaster
- The project already has shadcn/ui installed with 40+ components in `src/components/ui/`

## BUSINESS INFORMATION

```
Name: CareFirst Home Nursing Services
Phone: +91 98XXX XXXXX (raw: 9198XXXXXXXX)
WhatsApp: https://wa.me/9198XXXXXXXX
Email: care@carefirsthyd.in
Address: 3rd Floor, Sai Krupa Towers, Madhapur, Hyderabad, Telangana 500081
Geo: 17.4493, 78.3917
Website: https://www.carefirsthyd.in
Logo: https://www.carefirsthyd.in/logo.png
Founded: 2018
Hours: Mo-Su 00:00-23:59
Price Range: ₹₹
GTM ID: GTM-XXXXXXX (placeholder)
```

## PRICING & PROMO SYSTEM

- Promo code: `START50` (case-insensitive validation)
- Discount: 50% off on all services
- **CRITICAL PRICING RULE**: The `promoApplied` state must live in `page.tsx` and be passed as props to all components. Service cards must show:
  - **BEFORE promo code applied**: Show ONLY original price (e.g., `"Starting from ₹1,998/-"`) — NO slash, NO discount badge, NO "50% OFF" text
  - **AFTER promo code applied**: Show slashed original price (`~~₹1,998~~`) + red "50% OFF" badge + offered price (`₹999/-` in emerald green)
- This conditional rendering applies to: service cards grid, hero pricing teaser, service page pricing card
- The promo code banner in the hero ("50% OFF — Use Code: START50") and the red promo banner strip and the lead form's "Flat 50% OFF" banner are ALWAYS visible (they advertise the code). Only the pricing DISPLAY on cards changes.

## 19 SERVICES (with exact slugs, prices, icons, and 4 FAQs each)

Create a `src/lib/seo-data.ts` file with all business data, services, JSON-LD schema generators, and GTM tracking functions. Services array:

1. **Elder Care Services** — slug: `elder-care`, icon: `Heart`, originalCost: `₹1,998`, baselineCost: `₹999`
2. **Critical Care Nursing at Home** — slug: `critical-care-nursing`, icon: `Activity`, originalCost: `₹4,998`, baselineCost: `₹2,499`
3. **Post-Surgical Care** — slug: `post-surgical-care`, icon: `ShieldCheck`, originalCost: `₹2,398`, baselineCost: `₹1,199`
4. **Bedridden Patient Care** — slug: `bedridden-patient-care`, icon: `BedDouble`, originalCost: `₹2,198`, baselineCost: `₹1,099`
5. **Dementia & Alzheimer's Care** — slug: `dementia-care`, icon: `Brain`, originalCost: `₹2,598`, baselineCost: `₹1,299`
6. **Mother & Baby Care** — slug: `mother-baby-care`, icon: `Baby`, originalCost: `₹1,998`, baselineCost: `₹999`
7. **Injection & IV Administration** — slug: `injection-services`, icon: `Syringe`, originalCost: `₹998`, baselineCost: `₹499`
8. **Wound Care & Dressing** — slug: `wound-care`, icon: `Bandage`, originalCost: `₹798`, baselineCost: `₹399`
9. **Vitals Checking & Monitoring** — slug: `vitals-checking`, icon: `Thermometer`, originalCost: `₹598`, baselineCost: `₹299`
10. **Ryle's Tube Insertion** — slug: `ryles-tube-insertion`, icon: `Pill`, originalCost: `₹1,498`, baselineCost: `₹749`
11. **Foley Catheter Insertion** — slug: `foley-catheter-insertion`, icon: `Droplets`, originalCost: `₹1,298`, baselineCost: `₹649`
12. **Foley Catheter Removal** — slug: `foley-catheter-removal`, icon: `RotateCcw`, originalCost: `₹798`, baselineCost: `₹399`
13. **IV Infusion Therapy** — slug: `iv-infusion`, icon: `FlaskConical`, originalCost: `₹1,098`, baselineCost: `₹549`
14. **I/V Cannula Insertion** — slug: `iv-cannula-insertion`, icon: `PenLine`, originalCost: `₹898`, baselineCost: `₹449`
15. **S/C, IM Injection & Vaccination** — slug: `injection-vaccination`, icon: `Crosshair`, originalCost: `₹598`, baselineCost: `₹299`
16. **Enema Administration** — slug: `enema`, icon: `Waves`, originalCost: `₹698`, baselineCost: `₹349`
17. **Suture & Staple Removal** — slug: `suture-staple-removal`, icon: `Scissors`, originalCost: `₹698`, baselineCost: `₹349`
18. **General Random Blood Sugar (GRBS) Test** — slug: `grbs`, icon: `HeartPulse`, originalCost: `₹498`, baselineCost: `₹249`
19. **Colostomy Bag Change** — slug: `colostomy-bag-change`, icon: `RefreshCw`, originalCost: `₹998`, baselineCost: `₹499`

Each service needs: `slug`, `title`, `shortTitle`, `description` (SEO-rich, 2-3 sentences mentioning Hyderabad), `icon` (Lucide icon name string), `originalCost`, `baselineCost`, `discount: "50% OFF"`, and `faqs` array with 4 Q&A pairs each. FAQ answers should be detailed (3-5 sentences), mention Hyderabad, reference RN/ANM certification and background verification where relevant, and NEVER mention ISO certification. The critical care nursing FAQ must mention that CareFirst provides nursing staff only — medical equipment should be arranged separately by the family.

## FILE STRUCTURE

```
src/
├── app/
│   ├── layout.tsx              # Root layout with SEO meta, GTM, JSON-LD
│   ├── page.tsx                # Main page with client-side routing
│   ├── globals.css             # Tailwind v4 + custom CSS
│   └── api/
│       ├── route.ts            # Health check endpoint
│       ├── leads/route.ts      # POST lead capture + GET admin list
│       └── reviews/route.ts    # POST review + GET approved reviews
├── components/
│   ├── homecare/
│   │   ├── header.tsx          # Sticky header with nav + mobile sheet
│   │   ├── hero-section.tsx    # Hero gradient + lead form + pricing teaser
│   │   ├── services-section.tsx # 19 service cards grid (3-col)
│   │   ├── service-page-template.tsx # Individual service detail page
│   │   ├── comparison-section.tsx # Others vs CareFirst table (5 rows)
│   │   ├── trust-section.tsx   # Stats + Swathi V profile + Google reviews
│   │   ├── lead-form.tsx       # Lead capture form with promo code
│   │   ├── review-form.tsx     # Star rating + text review form
│   │   ├── footer.tsx          # 4-col footer with NAP
│   │   ├── mobile-bottom-bar.tsx # Fixed bottom call/whatsapp bar
│   │   └── gtm-scripts.tsx     # GTM script loader
│   └── ui/                     # shadcn/ui components (already installed)
├── lib/
│   ├── seo-data.ts             # ALL business data, services, schemas, tracking
│   ├── db.ts                   # Prisma singleton
│   └── utils.ts                # cn() utility
prisma/
└── schema.prisma               # Lead, Review, User, Post models
```

## DETAILED COMPONENT SPECS

### 1. `src/app/layout.tsx` (Root Layout)
- Import Inter font from `next/font/google`, apply as `--font-inter` CSS variable
- Full SEO metadata: title, description, keywords (15+ nursing/homecare keywords for Hyderabad), authors, OpenGraph, Twitter card, robots (index/follow), hreflang (en-IN, te-IN, hi-IN, x-default), favicon, apple-touch-icon
- Inject `MedicalOrganization` JSON-LD schema in `<head>`
- Preconnect to `wa.me`
- GTM noscript fallback iframe
- Render `<GTMScripts />` and `<Toaster />`

### 2. `src/app/page.tsx` (Main Page — Client-Side Router)
- "use client", uses `useState` for: `currentView` ("home" | "service"), `activeService` (string | null), `showPromoBanner` (boolean), `promoApplied` (boolean)
- `handlePromoApply` callback passed to child components
- `handleServiceClick` sets activeService + currentView="service" + scrolls to top
- `handleBackToHome` resets to home view + scrolls to top
- When `currentView === "service"`: render `<ServicePageTemplate>` with `promoApplied` and `onPromoApply` props
- When `currentView === "home"`: render in order:
  1. `<Header>`
  2. `<HeroSection>` with `promoApplied` and `onPromoApply`
  3. **Why Choose Us section** (inline in page.tsx) — 6 cards: 100% Verified Caregivers, RN/ANM Certified Staff, 24/7 Rapid Deployment, Pan-Hyderabad Coverage, Dedicated Care Coordinator, Transparent Pricing. Each card has icon, title, 2-sentence description.
  4. **Promo Banner** (dismissible red gradient strip) — shows "50% OFF — Limited Time Offer" with START50 code, close button
  5. `<ServicesSection>` with `onServiceClick` and `promoApplied`
  6. `<ComparisonSection>`
  7. `<TrustSection>`
  8. **Bottom CTA Banner** — dark emerald gradient, "Your Loved One Deserves the Best Care at Home", Call + WhatsApp buttons
  9. `<Footer>`
  10. `<MobileBottomBar>`

### 3. `src/components/homecare/header.tsx`
- Sticky, white/95% opacity with backdrop blur, subtle shadow
- **Top info bar** (hidden on mobile): email on left, "Available 24/7 for Emergencies" with pulsing green dot on right, dark emerald background
- **Logo**: Heart icon in emerald gradient box + "CareFirst" / "Home Nursing Services" text
- **Desktop nav**: Home, Services (hover dropdown showing all 19 services), About Us, Health Hub, Contact Us + Phone CTA button
- **Mobile nav**: Hamburger → Sheet (right side, 80/96w). Logo + close button at top. Home link, then "Services" label, then all 19 services listed, then About Us, Health Hub, Contact Us. Bottom: Call Now CTA button.
- Services dropdown items and mobile services list both use `handleNavClick("service", service.slug)`
- Import and use `trackPhoneCallClick` on phone links

### 4. `src/components/homecare/hero-section.tsx`
- Full-width dark emerald gradient background (`.hero-gradient` class) with decorative blurred circles and dot pattern overlay
- Grid: 2 cols on lg, stacked on mobile. Left = text, Right = LeadForm
- **Promo badge** (always visible): red gradient pill with Sparkles icon, "50% OFF", code "START50" — has `animate-promo-pulse`
- **Trust micro badges** (4 pills): RN/ANM Certified, 24/7 Available, 7+ Years Experience, 4.8/5 Rating
- **H1**: "Trusted Nursing" + line 2 "Homecare in Hyderabad" (emerald gradient text)
- **Description**: mentions expert home nurses, ICU-trained staff, 100% background-verified, RN/ANM certified
- **Pricing teaser card** (glassmorphism — `bg-white/8 backdrop-blur-md`):
  - When `promoApplied=false`: "₹1,998/-" only (white, large) + small text "*Apply promo code START50 in the form for 50% off"
  - When `promoApplied=true`: `~~₹1,998~~` (white/40, line-through) + "₹999/-" (white, huge) + red badge "50% OFF Applied"
- WhatsApp Us button (green) — only CTA button, no separate Call button here
- **NAP** (Name, Address, Phone) at bottom with schema.org markup
- Props: `onPromoApply: (applied: boolean) => void`, `promoApplied: boolean`

### 5. `src/components/homecare/services-section.tsx`
- Section label badge ("Our Services"), heading, description
- When `promoApplied`: show a banner "50% OFF Applied on All Services!" with Sparkles icon
- **3-column grid** (sm:2, lg:3) of service cards
- Each card is a `<button>` that calls `onServiceClick(service.slug)`
- **Icon map**: Import 18 Lucide icons (Heart, Activity, ShieldCheck, BedDouble, Brain, Baby, Syringe, Bandage, Thermometer, Pill, Droplets, RotateCcw, FlaskConical, PenLine, Crosshair, Waves, Scissors, HeartPulse, RefreshCw) and map by name string
- Each card:
  - Stagger animation class `stagger-{(idx % 9) + 1}` with `animate-fade-in-up` and `opacity-0`
  - Icon in emerald gradient box (top-left)
  - **When `promoApplied=true` only**: red "50% OFF" badge (top-right)
  - Title (bold, emerald on hover)
  - Description (first 110 chars + "...")
  - Divider line, then:
    - **When `promoApplied=false`**: `"Starting from ₹1,998/-"` (gray-900, bold, single line)
    - **When `promoApplied=true`**: `"~~₹1,998~~"` (muted, line-through, small) + `"₹999/-"` (emerald-700, bold, larger)
  - "Details →" link (emerald, shifts right on hover)
- Uses `premium-card` class
- Props: `onServiceClick: (slug: string) => void`, `promoApplied: boolean`

### 6. `src/components/homecare/service-page-template.tsx`
- Props: `serviceSlug`, `onBack`, `promoApplied`, `onPromoApply?`
- Find service from SERVICES array by slug
- Inject FAQ + MedicalTherapy JSON-LD schemas
- **Breadcrumb**: Home / Services / {service.title}
- **Service Hero**: Dark emerald gradient, Back button, H1 "{title} in Hyderabad", description, WhatsApp + Call buttons, placeholder image area (right side, lg only)
- **How It Works**: 4 steps — 1) Share Requirements (NOT "Free Assessment"), 2) Care Plan, 3) Nurse Matching, 4) Care Begins
- **Pricing Card** (centered, max-w-lg, white with emerald border):
  - When `promoApplied=true`: red badge "{discount} — Limited Time Offer", slashed original + baseline price
  - When `promoApplied=false`: emerald badge "Standard Pricing", original price only
  - "Actual cost depends on medical complexity" disclaimer
  - Promo code display box: Sparkles icon + "Promo: START50 = 50% OFF"
- **Lead Form** (inline variant) — renders `<LeadForm variant="inline" onPromoApply={onPromoApply} />`
- **FAQ Section**: Accordion using `<details>` elements with `faq-item` class, green +/- toggle icons, max-w-3xl
- **Bottom CTA**: Dark emerald gradient, "Need {shortTitle} in Hyderabad?", Call + WhatsApp buttons

### 7. `src/components/homecare/comparison-section.tsx`
- "Honest Comparison" section label
- Table with 3 columns: Feature | CareFirst (green header with Trophy icon) | Others
- **Exactly 5 rows**:
  1. Nurse Certification — CareFirst: "RN/ANM Certified Nurses" / Others: "Unverified or minimal training"
  2. Response Time — CareFirst: "2-4 hours emergency deployment" / Others: "24-48 hours or more"
  3. Care Coordinator — CareFirst: "Dedicated single point of contact" / Others: "No assigned coordinator"
  4. Pricing Transparency — CareFirst: "Upfront cost, no hidden charges" / Others: "Hidden charges common"
  5. Service Areas — CareFirst: "Pan-Hyderabad coverage" / Others: "Limited areas only"
- CareFirst cells: CheckCircle2 icon (emerald), green bg tint
- Others cells: XCircle icon (red-300), gray text
- Hover effect on rows: `comparison-table-row:hover` turns green tint
- Bottom CTA: dark emerald card with Trophy icon, "Choose the Trusted Name in Home Nursing", mentions 1,200+ families, 350+ nurses, 4.8/5 rating

### 8. `src/components/homecare/trust-section.tsx`
- Background: `bg-gray-50/80`
- **Stats Row** (4 cols): 1,200+ Families Served, 350+ Verified Nurses, 4.8/5 Google Rating, 7+ Years of Service. White cards with emerald numbers.
- **Meet Our Senior Nursing Specialist** — SINGLE profile card only:
  - Name: Swathi V
  - Title: Senior Nursing Specialist
  - Credentials: B.Sc. Nursing, ICU Trained
  - Experience: 12+ years experience
  - Description: "Specialized in critical care nursing, post-surgical recovery, and complex home care management. Leads our clinical team with expertise in ICU protocols, wound care, and patient-centered nursing care at home."
  - NO registration field (no TNMC, no council registration)
  - Centered card with Stethoscope icon in emerald gradient box, premium-card styling
  - Below card: "100% RN/ANM Certified Nursing Staff" badge
- **Google Reviews Section**:
  - Header: 5 gold stars + "Google Reviews" + "(342 reviews, 4.8 avg)" + "Write a Review" toggle button
  - 4 default reviews hardcoded (Rajesh K. 5★, Lakshmi P. 5★, Srinivas M. 4★, Anitha R. 5★)
  - Fetches approved reviews from `/api/reviews` on mount, merges with defaults (user reviews first)
  - Toggle between reviews grid and ReviewForm component

### 9. `src/components/homecare/lead-form.tsx`
- Props: `variant` ("hero" | "inline"), `page` (string), `onPromoApply?: (applied: boolean) => void`
- **Local state**: name, phone, careType, promoCode, promoApplied (local), promoError, dpdpConsent, submitted, submitting, errors
- **Heading**: "Book Home Nursing Care" (NOT "Book a Free Assessment")
- **Subtext**: "Get expert care advice within 15 minutes."
- **Promo Code Banner** (always visible): Red gradient with shimmer animation, "Flat 50% OFF", code display
- **Form fields**:
  1. Name input (text, autoComplete="name")
  2. Phone input (tel, +91 prefix, 10-digit only, regex validation `^[6-9]\d{9}$`)
  3. Care Type select (dropdown with all 19 services from SERVICES + "Other / Not Sure")
  4. Promo Code input with Apply button:
     - Tag icon inside input
     - Validate case-insensitive: `promoCode.trim().toUpperCase() === "START50"`
     - On success: green border, CheckCircle2 icon, green text "50% discount applied!"
     - On failure: red border, "Invalid promo code" error
     - **Also calls `onPromoApply?.(true)` on success to lift state to parent**
     - Editing the promo code after apply resets both local and parent state
  5. Submit button: When promoApplied → "Book Now with 50% OFF" (emerald gradient), else → "Book Home Nursing Care" (emerald solid)
  6. "Call Now for Immediate Care" button (red border, phone icon)
  7. DPDP Act 2023 consent checkbox (mandatory, with business name)
- On submit: validate all fields, track via GTM, POST to `/api/leads` with `{ name, phone, careType, page, promoCode }`
- On success: show thank you card with CheckCircle2 icon, "We'll Call You Shortly", promo confirmation if applied
- Auto-reset form after 5 seconds

### 10. `src/components/homecare/review-form.tsx`
- Star rating (1-5, interactive with hover, amber color, shows X/5)
- Name input (max 50 chars)
- Service dropdown (optional, uses SERVICES shortTitle)
- Review textarea (min 10 chars, max 500, shows char count)
- "Post to Google Business" checkbox
- Client-side validation before submit
- POSTs to `/api/reviews` with `{ name, rating, text, service, postToGoogle }`
- Success state: Thank you card with Google Business mention if checked

### 11. `src/components/homecare/footer.tsx`
- Dark gray background (`bg-gray-900`), `pb-mobile-bar` class for bottom bar spacing
- **Trust badges bar** (emerald gradient): "RN/ANM Certified Nurses", "Telangana Nurses Council Registered", "Data Secure & DPDP Compliant"
- **4-column grid**:
  1. Brand (logo + name) + description ("Trusted home nursing services in Hyderabad since 2018. Background-verified, certified staff delivering compassionate medical care at your doorstep.") + NAP info (address, phone, email with icons)
  2. Our Services (all 19 service names as text links)
  3. Quick Links (About Us, Health Hub, Careers, Privacy Policy, Terms of Service, DPDP Compliance)
  4. Service Areas (Jubilee Hills, Banjara Hills, Madhapur, Kukatpally, Gachibowli, HITEC City, Kondapur, Miyapur, Secunderabad, Ameerpet)
- Bottom bar: copyright with dynamic year + WhatsApp CTA button
- NO ISO 9001:2015 mention anywhere

### 12. `src/components/homecare/mobile-bottom-bar.tsx`
- Fixed bottom bar, hidden on lg+ (`lg:hidden`)
- Two equal-width buttons: "Call Now" (emerald gradient) + "WhatsApp" (green gradient)
- Uses `mobile-bottom-bar` CSS class
- Tracks clicks via GTM

### 13. `src/components/homecare/gtm-scripts.tsx`
- Loads GTM script using Next.js `<Script>` with `afterInteractive` strategy
- GTM_ID = "GTM-XXXXXXX" (placeholder)

## DATABASE (Prisma + SQLite)

### Schema (`prisma/schema.prisma`):
```
generator client { provider = "prisma-client-js" }
datasource db { provider = "sqlite" url = env("DATABASE_URL") }

model Lead {
  id         String   @id @default(cuid())
  name       String
  phone      String
  careType   String
  page       String   @default("home")
  source     String   @default("website")
  status     String   @default("new")
  dpdpConsent Boolean  @default(true)
  promoCode  String?  @default("")
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
}

model Review {
  id            String   @id @default(cuid())
  name          String
  rating        Int
  text          String
  service       String?
  approved      Boolean  @default(false)
  postedToGoogle Boolean  @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Post {
  id        String   @id @default(cuid())
  title     String
  content   String?
  published Boolean  @default(false)
  authorId  String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
```

### API Routes:

**`/api/leads`**:
- POST: Validates name/phone/careType, creates Lead in DB, has commented-out notification hooks (Twilio WhatsApp, Twilio SMS, Resend email, Google Sheets, Zapier webhook)
- GET: Returns last 50 leads ordered by createdAt desc

**`/api/reviews`**:
- POST: Validates name/rating(1-5)/text(min 10 chars), creates Review (approved=false, postedToGoogle flag), returns success message
- GET: Returns approved reviews (max 20) ordered by createdAt desc

### DB client (`src/lib/db.ts`):
- Prisma singleton pattern with globalThis caching for dev hot-reload

## SEO & SCHEMAS (`src/lib/seo-data.ts`)

- **`getMedicalOrganizationSchema()`**: Returns JSON-LD MedicalOrganization with all business info, areaServed (Hyderabad, Telangana), aggregateRating (4.8/5, 342 reviews), sameAs social links
- **`getFAQSchema(faqs)`**: Returns FAQPage JSON-LD
- **`getServiceSchema(service)`**: Returns MedicalTherapy JSON-LD for each service
- **`trackWhatsAppClick()`**: Pushes `{event: "whatsapp_click"}` to dataLayer
- **`trackPhoneCallClick()`**: Pushes `{event: "phone_call_click"}` to dataLayer
- **`trackFormSubmission(formData)`**: Pushes `{event: "form_submission", form_data}` to dataLayer

## GLOBAL CSS (`src/app/globals.css`)

- `@import "tailwindcss"` and `@import "tw-animate-css"`
- Custom theme with emerald/teal/amber/rose/gold color palette
- CSS variables for all shadcn colors mapped to emerald-based brand palette
- Base styles: 16px root, smooth scroll, Inter font, custom heading sizes (h1: 2.5rem, h2: 2rem, etc. with mobile overrides)
- `.mobile-bottom-bar`: Fixed bottom, 60px height, flex, safe-area-inset support, `.pb-mobile-bar` for page bottom padding
- `.hero-gradient`: 5-stop dark emerald gradient (135deg)
- `.premium-card`: White card with subtle shadow, 1rem radius, hover: translateY(-4px) + emerald shadow + border color change
- `.trust-badge`: Hover lift effect
- `.faq-item`: Custom accordion with green +/- circle icons, no webkit marker
- `.animate-fade-in-up`: fadeInUp keyframe (0.7s, cubic-bezier), `.animate-shimmer`, `.animate-promo-pulse`
- `.stagger-1` through `.stagger-9`: Animation delays (0.05s increments)
- `.comparison-table-row`: Hover turns green tint
- `.section-divider`: 4px gradient line (transparent → emerald → transparent)

## CRITICAL RULES — DO NOT VIOLATE

1. **NO "ISO" anywhere** — No ISO 9001, no ISO certification, no ISO references in any file (code, comments, schemas, FAQs, meta descriptions, alt text, data)
2. **NO "Free Assessment"** — Never use this phrase. Use "Share Requirements", "consultation", or "care advice" instead
3. **NO "Background Verification" as a comparison row** — Removed from comparison table
4. **NO "Nurse Replacement" as a comparison row** — Removed from comparison table
5. **NO "TNMC Registered"** — Do not use this phrase anywhere. Use "RN/ANM Certified" or "Telangana Nurses Council Registered" instead
6. **NO "ISO Certification" as a comparison row** — Removed from comparison table
7. **Promo pricing is CONDITIONAL** — 50% OFF display (slashed prices, badges) ONLY appears after user applies START50 code. Before that, show only original prices.
8. **Single specialist profile** — Only Swathi V in trust section, no other team member profiles
9. **All text in English** — No Hindi/Telugu content in UI (hreflang tags are fine for SEO readiness)
10. **YMYL compliance** — This is a Your Money Your Life site. All medical claims must be accurate. Include disclaimers where appropriate (e.g., "Actual cost depends on medical complexity", doctor's prescription required for injections)

## BUILD & RUN

```bash
npx prisma db push --accept-data-loss   # Create SQLite DB
npx prisma generate                      # Generate Prisma client
npm run build                           # Build for production (standalone output)
node .next/standalone/server.js         # Run production server on port 3000
```

Build script: `"build": "next build && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/"`
