// ============================================================
// SEO Data, Schemas, and Configuration
// ============================================================

export const BUSINESS = {
  name: "CareFirst Home Nursing Services",
  phone: "+91 98XXX XXXXX",
  phoneRaw: "9198XXXXXXXX",
  whatsappUrl: "https://wa.me/9198XXXXXXXX",
  email: "care@carefirsthyd.in",
  address: {
    streetAddress: "3rd Floor, Sai Krupa Towers, Madhapur",
    addressLocality: "Hyderabad",
    addressRegion: "Telangana",
    postalCode: "500081",
    addressCountry: "IN",
  },
  geo: { latitude: 17.4493, longitude: 78.3917 },
  url: "https://www.carefirsthyd.in",
  logo: "https://www.carefirsthyd.in/logo.png",
  foundedYear: 2018,
  openingHours: "Mo-Su 00:00-23:59",
  priceRange: "₹₹",
};

// Doctor/Staff profiles removed per business requirements
// Care team information available on request during assessment

export const PROMO_CODE = "START50";
export const PROMO_DISCOUNT = 50; // percentage

export const SERVICES = [
  {
    slug: "elder-care",
    title: "Elder Care Services",
    shortTitle: "Elder Care",
    description: "Compassionate senior citizen caretaker services in Hyderabad. Our trained nurses provide 24/7 elderly care, medication management, injection administration, vitals checking, mobility support, and companionship for your loved ones at home.",
    icon: "Heart",
    originalCost: "₹1,998",
    baselineCost: "₹999",
    discount: "50% OFF",
    faqs: [
      { question: "What does elder care at home in Hyderabad include?", answer: "Our elder care services include 24/7 or hourly nursing support, medication reminders and administration, injection services, vitals checking, mobility and physiotherapy assistance, personal hygiene help, nutritious meal planning, companionship, and regular health monitoring. All caregivers are RN/ANM certified and background-verified." },
      { question: "How much does a senior citizen caretaker cost in Hyderabad?", answer: "Elder care services in Hyderabad are currently available at a special 50% discount, starting from ₹999. The standard rate is ₹1,998. Costs vary based on medical complexity and level of nursing expertise needed. We provide a detailed consultation to give you an accurate quote." },
      { question: "Are your elder care nurses background-verified in Telangana?", answer: "Absolutely. Every caregiver at CareFirst undergoes a rigorous 7-point background verification including police records check, TS Nurses Council registration verification, credential authentication, and reference checks. We maintain 100% verified staff as part of our rigorous quality management processes." },
      { question: "Can I get elder care for dementia patients at home?", answer: "Yes, we specialize in dementia and Alzheimer's care at home. Our nurses are trained in cognitive stimulation therapy, behavioral management, wandering prevention, and creating safe home environments. We work closely with your neurologist to follow the prescribed care plan." },
    ],
  },
  {
    slug: "critical-care-nursing",
    title: "Critical Care Nursing at Home",
    shortTitle: "Critical Care",
    description: "Expert ICU-trained nurses for critically ill patients at home in Hyderabad. Our nurses provide hospital-grade bedside care including vital monitoring, injection administration, and doctor coordination. We provide the nursing staff — you arrange the medical equipment separately.",
    icon: "Activity",
    originalCost: "₹4,998",
    baselineCost: "₹2,499",
    discount: "50% OFF",
    faqs: [
      { question: "What does critical care nursing at home include?", answer: "Our critical care nurses provide 24/7 bedside nursing for patients who are critically ill and being managed at home. This includes continuous vital sign monitoring, injection administration (IM, IV), wound care, catheter and drain management, patient positioning, and daily reporting to your treating doctor. We provide the expert nursing staff — medical equipment such as monitors, ventilators, or oxygen concentrators should be arranged separately by the family or through your hospital." },
      { question: "Who manages the critical care at home?", answer: "A trained ICU nurse provides 24/7 bedside care at your home, following the treatment plan prescribed by your primary treating physician. Our nursing coordinators oversee care quality and coordinate regularly with your doctor, providing detailed daily health reports to ensure the highest standards of home-based critical care." },
      { question: "How quickly can you deploy a critical care nurse in Hyderabad?", answer: "We can deploy a trained critical care nurse to your home within 15 minutes to 1 hour of confirmation. For urgent cases, emergency deployment is available even faster, subject to nurse availability. Please ensure that the necessary medical equipment prescribed by your doctor is already arranged at home." },
      { question: "Is home critical care nursing covered by insurance?", answer: "Many health insurance plans now cover home-based nursing care under their domiciliary treatment benefit. We provide detailed medical bills and reports required for insurance claims. Please check with your insurance provider for specific coverage details." },
    ],
  },
  {
    slug: "post-surgical-care",
    title: "Post-Surgical Care",
    shortTitle: "Post-Surgery",
    description: "Expert post-operative nursing care at home in Hyderabad. Wound dressing, injection administration, vitals checking, physiotherapy coordination, medication, and recovery monitoring after surgery by experienced surgical nurses.",
    icon: "ShieldCheck",
    originalCost: "₹2,398",
    baselineCost: "₹1,199",
    discount: "50% OFF",
    faqs: [
      { question: "What does post-surgical home care include?", answer: "Post-surgical care includes surgical wound dressing and infection monitoring, injection administration (IM, IV, subcutaneous), pain management, medication supervision, vitals checking, catheter and drain management, dietary guidance, and daily progress reporting to your surgeon." },
      { question: "How long do I need a nurse after surgery at home?", answer: "The duration depends on the surgery type. Minor procedures may need 3-7 days of nursing support, while major surgeries like joint replacement or cardiac surgery typically require 2-6 weeks. Your surgeon and our nursing coordinator will create a personalized recovery timeline." },
      { question: "Can you coordinate with my hospital for discharge planning?", answer: "Yes, we work directly with hospitals across Hyderabad including Apollo, KIMS, Yashoda, and Care Hospitals. Our discharge planning team coordinates with your surgical team to ensure a smooth transition from hospital to home with no gap in care." },
      { question: "Do you provide physiotherapy alongside post-surgical nursing?", answer: "Yes, we offer integrated post-surgical rehabilitation. Our physiotherapists work alongside nurses to provide mobility exercises, gait training, and pain management." },
    ],
  },
  {
    slug: "bedridden-patient-care",
    title: "Bedridden Patient Care",
    shortTitle: "Bedridden Care",
    description: "Specialized bedridden patient support at home in Hyderabad. Pressure sore prevention, turning and positioning, catheter care, injection administration, vitals monitoring, and compassionate nursing for bed-bound individuals.",
    icon: "BedDouble",
    originalCost: "₹2,198",
    baselineCost: "₹1,099",
    discount: "50% OFF",
    faqs: [
      { question: "How do you prevent bedsores for bedridden patients at home?", answer: "Our nurses follow evidence-based pressure ulcer prevention protocols: 2-hourly turning and repositioning, skin assessment and moisture management, nutritional optimization, and range-of-motion exercises. We maintain detailed skin integrity charts." },
      { question: "What nursing support is needed for bedridden patients?", answer: "Bedridden patient care includes 24/7 nursing for hygiene and toileting, feeding and nutrition management, catheter and Ryle's tube care, injection administration, vitals monitoring, physiotherapy for muscle tone maintenance, respiratory care, and emotional support." },
      { question: "Can bedridden patient care be provided part-time?", answer: "While 24/7 care is recommended for fully bedridden patients, we offer flexible 12-hour or 8-hour shifts for families who share caregiving responsibilities." },
      { question: "Do you provide injection services for bedridden patients?", answer: "Yes, our nurses are trained and certified to administer all types of injections including IM, subcutaneous, and IV injections as prescribed by the treating doctor." },
    ],
  },
  {
    slug: "dementia-care",
    title: "Dementia & Alzheimer's Care",
    shortTitle: "Dementia Care",
    description: "Specialized dementia care assistance at home in Hyderabad. Cognitive stimulation, behavioral management, safety supervision, vitals checking, and compassionate support for dementia patients.",
    icon: "Brain",
    originalCost: "₹2,598",
    baselineCost: "₹1,299",
    discount: "50% OFF",
    faqs: [
      { question: "What is specialized dementia care at home?", answer: "Specialized dementia care involves trained nurses who understand the progressive nature of cognitive decline. Services include cognitive stimulation activities, behavioral management, structured daily routines, safety supervision, medication adherence, vitals monitoring, and caregiver education." },
      { question: "How do dementia caregivers handle behavioral issues?", answer: "Our dementia-trained nurses use non-pharmacological behavioral interventions: validation therapy, redirection techniques, maintaining a calm environment, and identifying triggers for agitation." },
      { question: "At what stage of dementia should I consider home nursing?", answer: "Home nursing can be beneficial at any stage. We customize care plans for each stage — from early cognitive support to late-stage 24/7 medical management." },
      { question: "Do you provide dementia caregiver training for family members?", answer: "Yes, we offer a structured 3-day family caregiver training program covering dementia understanding, communication techniques, behavioral management, and emergency handling." },
    ],
  },
  {
    slug: "mother-baby-care",
    title: "Mother & Baby Care",
    shortTitle: "Mother & Baby",
    description: "Post-delivery mother and newborn care at home in Hyderabad. Lactation support, injection administration, infant bathing, vitals checking, umbilical cord care, and maternal recovery by experienced nurses.",
    icon: "Baby",
    originalCost: "₹1,998",
    baselineCost: "₹999",
    discount: "50% OFF",
    faqs: [
      { question: "What does post-delivery home nursing care include?", answer: "Our mother and baby care includes post-C-section or normal delivery wound care, injection administration, lactation support, newborn bathing and hygiene, umbilical cord care, baby massage, maternal nutrition guidance, vitals monitoring, and vaccination schedule tracking." },
      { question: "How long should I have a nurse after delivery at home?", answer: "We recommend a minimum of 15-30 days of post-delivery nursing support. For C-section recoveries, 30-45 days is ideal." },
      { question: "Are your mother-baby care nurses trained in lactation support?", answer: "Yes, all our mother-baby care nurses are certified in lactation management. They help with latching techniques, breast engorgement management, and feeding schedules." },
      { question: "Do you provide newborn vaccination reminders?", answer: "Absolutely. Our nurses maintain a detailed immunization tracker and provide timely reminders for every vaccination due as per the IAP schedule." },
    ],
  },
  {
    slug: "injection-services",
    title: "Injection & IV Administration",
    shortTitle: "Injections",
    description: "Trained nurses for home injection services in Hyderabad. We administer intramuscular (IM), subcutaneous, intravenous (IV) injections, and IV drips as prescribed by your doctor — safely at your doorstep.",
    icon: "Syringe",
    originalCost: "₹998",
    baselineCost: "₹499",
    discount: "50% OFF",
    faqs: [
      { question: "What types of injections can your nurses administer at home?", answer: "Our certified nurses can administer intramuscular (IM) injections, subcutaneous injections (insulin, blood thinners), intravenous (IV) injections, and IV drip/infusion therapy. All injections are administered strictly as per your doctor's prescription." },
      { question: "Is it safe to get injections at home in Hyderabad?", answer: "Absolutely. Our nurses follow strict infection control protocols using sterile, sealed needles and syringes for every injection. All nurses are ANM/GNM certified and experienced in injection administration." },
      { question: "Do I need a doctor's prescription for home injection services?", answer: "Yes, a valid doctor's prescription is mandatory for all injection services. You can share the prescription via WhatsApp before our nurse visits." },
      { question: "Can you provide IV drips and infusions at home?", answer: "Yes, our nurses are trained to set up and monitor IV drips and infusion therapy at home including antibiotics and hydration therapy as prescribed." },
    ],
  },
  {
    slug: "wound-care",
    title: "Wound Care & Dressing",
    shortTitle: "Wound Care",
    description: "Professional wound care and dressing services at home in Hyderabad. Surgical wound dressing, diabetic ulcer care, pressure sore management, and infection prevention by experienced nursing staff.",
    icon: "Bandage",
    originalCost: "₹798",
    baselineCost: "₹399",
    discount: "50% OFF",
    faqs: [
      { question: "What types of wounds do you treat at home?", answer: "Our nurses provide care for post-surgical incisions, diabetic foot ulcers, pressure sores, traumatic wounds, abscess drainage sites, and burn wounds." },
      { question: "How often should wound dressing be changed?", answer: "It depends on the wound type and your doctor's instructions. Typically, surgical wounds are dressed every 1-3 days, while infected wounds may need daily changes." },
      { question: "Do you provide wound care supplies?", answer: "Our nurse will guide you on what dressing materials to keep at home. You can purchase these from any medical store. The nurse brings basic sterile supplies for the first visit." },
      { question: "Can wound care be combined with other nursing services?", answer: "Yes, wound care is often part of a broader care plan. Many post-surgical and bedridden patient packages include wound dressing. You can also opt for standalone visit-based service." },
    ],
  },
  {
    slug: "vitals-checking",
    title: "Vitals Checking & Monitoring",
    shortTitle: "Vitals Check",
    description: "Regular vitals monitoring at home in Hyderabad. Our nurses check blood pressure, temperature, pulse, oxygen saturation, blood sugar levels, and report to your doctor for timely health management.",
    icon: "Thermometer",
    originalCost: "₹598",
    baselineCost: "₹299",
    discount: "50% OFF",
    faqs: [
      { question: "What vitals do your nurses check at home?", answer: "Our nurses measure blood pressure, body temperature, pulse rate, respiratory rate, oxygen saturation (SpO2), and blood sugar levels. They also record and track trends over time, reporting any abnormalities to your treating doctor." },
      { question: "How often should vitals be monitored at home?", answer: "For stable patients, once or twice daily is common. For post-surgical, critical care, or chronically ill patients, vitals may need to be checked every 2-4 hours. Your doctor will recommend the appropriate frequency." },
      { question: "Do you provide the equipment for vitals checking?", answer: "Our nurses carry digital BP monitors, thermometers, pulse oximeters, and glucometers for vitals checking at home. There is no additional charge for equipment usage during the visit." },
      { question: "Can vitals checking be combined with injection services?", answer: "Yes, vitals checking is often done alongside injection administration, wound care, or as part of comprehensive home nursing. We offer flexible packages that combine multiple services." },
    ],
  },
  {
    slug: "ryles-tube-insertion",
    title: "Ryle's Tube Insertion",
    shortTitle: "Ryle's Tube",
    description: "Professional Ryle's tube (nasogastric tube) insertion service at home in Hyderabad. Our trained nurses perform safe, sterile NG tube placement for feeding and gastric decompression as prescribed by your doctor.",
    icon: "Pill",
    originalCost: "₹1,498",
    baselineCost: "₹749",
    discount: "50% OFF",
    faqs: [
      { question: "What is a Ryle's tube insertion?", answer: "A Ryle's tube (nasogastric tube) is a thin, flexible tube passed through the nose into the stomach. It is used for nutritional feeding, administering medications, or gastric decompression when a patient cannot swallow safely. Our nurses perform this procedure at home following strict aseptic techniques." },
      { question: "Is Ryle's tube insertion at home safe?", answer: "Yes, when performed by a trained nurse. Our nurses are experienced in NG tube insertion and follow hospital-grade protocols including proper tube measurement, placement verification, and patient comfort techniques. A doctor's prescription is required." },
      { question: "How long does the Ryle's tube insertion procedure take?", answer: "The procedure typically takes 10-15 minutes. Our nurse will also guide the caregiver on feeding through the tube, flushing protocols, and when to seek medical attention." },
      { question: "Do you also provide Ryle's tube removal services?", answer: "Yes, we provide both insertion and removal services. Our nurses can also assist with tube replacement if needed." },
    ],
  },
  {
    slug: "foley-catheter-insertion",
    title: "Foley Catheter Insertion",
    shortTitle: "Catheter Insertion",
    description: "Safe and sterile Foley catheter insertion at home in Hyderabad. Our certified nurses perform urinary catheterization using hospital-grade aseptic techniques for patients who need bladder drainage at home.",
    icon: "Droplets",
    originalCost: "₹1,298",
    baselineCost: "₹649",
    discount: "50% OFF",
    faqs: [
      { question: "What is a Foley catheter insertion?", answer: "A Foley catheter is a sterile flexible tube inserted into the bladder through the urethra to drain urine. It is commonly needed for patients with urinary retention, post-surgery recovery, or bedridden patients who cannot use the bathroom independently." },
      { question: "Is Foley catheter insertion safe at home?", answer: "Absolutely. Our nurses follow strict sterile (no-touch) catheterization techniques using hospital-grade sterile kits. The procedure is safe when performed by trained professionals in a clean home environment." },
      { question: "How long can a Foley catheter stay in place?", answer: "A Foley catheter can typically remain in place for 2-4 weeks before requiring replacement. Our nurses provide catheter care guidance and can schedule regular replacements as needed." },
      { question: "Do you provide the catheter kit or should I arrange it?", answer: "The family should arrange the Foley catheter kit (available at any medical supply store). Our nurse will guide you on exactly what to purchase. The nurse brings sterile gloves and ancillary supplies." },
    ],
  },
  {
    slug: "foley-catheter-removal",
    title: "Foley Catheter Removal",
    shortTitle: "Catheter Removal",
    description: "Professional Foley catheter removal service at home in Hyderabad. Our nurses safely remove urinary catheters and assess bladder function to ensure the patient can void normally after removal.",
    icon: "RotateCcw",
    originalCost: "₹798",
    baselineCost: "₹399",
    discount: "50% OFF",
    faqs: [
      { question: "How is a Foley catheter removed at home?", answer: "Our nurse deflates the retention balloon using a syringe, then gently withdraws the catheter. The procedure takes 2-5 minutes and is generally painless. The nurse then monitors the patient's ability to urinate naturally." },
      { question: "Is catheter removal painful?", answer: "Most patients experience minimal discomfort during catheter removal. A slight tingling sensation is normal. Our nurses are gentle and experienced in making the process as comfortable as possible." },
      { question: "What should I do if I cannot urinate after catheter removal?", answer: "If you are unable to urinate within 6-8 hours after catheter removal, contact us or your doctor immediately. Our nurse will assess the situation and advise on next steps." },
      { question: "Do I need a doctor's prescription for catheter removal?", answer: "Yes, a doctor's instruction for catheter removal is required. This ensures it is medically safe to remove the catheter at that time." },
    ],
  },
  {
    slug: "iv-infusion",
    title: "IV Infusion Therapy",
    shortTitle: "IV Infusion",
    description: "Intravenous (IV) infusion and drip therapy at home in Hyderabad. Our nurses set up and monitor IV drips including antibiotics, hydration therapy, and other IV medications as prescribed by your doctor.",
    icon: "FlaskConical",
    originalCost: "₹1,098",
    baselineCost: "₹549",
    discount: "50% OFF",
    faqs: [
      { question: "What is IV infusion therapy at home?", answer: "IV infusion involves administering fluids, antibiotics, or other medications directly into a vein through a drip setup. Our trained nurses manage the entire process including IV line setup, drip rate monitoring, and patient observation during and after the infusion." },
      { question: "What types of IV infusions can be given at home?", answer: "Common home IV infusions include antibiotics, IV fluids for dehydration, electrolyte replacements, and vitamin infusions. All IV therapies require a valid doctor's prescription specifying the medication, dosage, and duration." },
      { question: "How long does an IV infusion session take at home?", answer: "The duration depends on the prescribed medication and volume. Most IV infusions take 30 minutes to 2 hours. Our nurse stays throughout the session to monitor the drip rate and watch for any adverse reactions." },
      { question: "Is IV infusion at home safe?", answer: "Yes. Our nurses are trained in IV therapy management, infection control, and adverse reaction handling. They follow strict protocols and carry emergency supplies. The doctor's prescription and medication should be arranged by the family." },
    ],
  },
  {
    slug: "iv-cannula-insertion",
    title: "I/V Cannula Insertion",
    shortTitle: "Cannula Insertion",
    description: "Expert intravenous cannula insertion at home in Hyderabad. Our skilled nurses place IV cannulas for ongoing medication administration, blood draws, or drip therapy — using sterile, hospital-grade technique.",
    icon: "PenLine",
    originalCost: "₹898",
    baselineCost: "₹449",
    discount: "50% OFF",
    faqs: [
      { question: "What is an IV cannula insertion?", answer: "An IV cannula is a small, flexible tube inserted into a vein, usually in the arm or hand. It provides secure access for administering IV medications, fluids, or for blood sampling over multiple days without repeated needle pricks." },
      { question: "How long does an IV cannula stay in place?", answer: "A peripheral IV cannula typically stays in place for 48-72 hours before it needs to be replaced. Our nurses follow strict rotation protocols and can perform replacement when due." },
      { question: "Does IV cannula insertion hurt?", answer: "There is a brief needle prick during insertion, similar to a blood draw. Once placed, the cannula should not cause pain. Our nurses use the finest gauge cannulas appropriate for the therapy and use numbing techniques when possible." },
      { question: "Do you also provide cannula removal?", answer: "Yes, our nurses can both insert and remove IV cannulas. They also provide cannula site care and monitoring during the duration it remains in place." },
    ],
  },
  {
    slug: "injection-vaccination",
    title: "S/C, IM Injection & Vaccination",
    shortTitle: "Injections & Vaccination",
    description: "Complete injection and vaccination services at home in Hyderabad. Our nurses administer subcutaneous (S/C), intramuscular (IM) injections, and vaccinations — including insulin, blood thinners, and scheduled immunizations.",
    icon: "Crosshair",
    originalCost: "₹598",
    baselineCost: "₹299",
    discount: "50% OFF",
    faqs: [
      { question: "What types of injections do you administer at home?", answer: "Our nurses administer subcutaneous injections (insulin, blood thinners like Enoxaparin), intramuscular injections (antibiotics, vitamins, pain medications), and intradermal injections. Vaccinations including flu shots, tetanus, and other scheduled immunizations are also provided." },
      { question: "Do I need a doctor's prescription for injections at home?", answer: "Yes, a valid doctor's prescription is mandatory for all injection services. For vaccinations, a prescription or vaccination card is required. You can share the prescription via WhatsApp before our nurse visits." },
      { question: "How do you ensure injection safety at home?", answer: "Our nurses follow strict infection control protocols: hand hygiene, sterile technique, use of sealed disposable syringes and needles for every injection, proper site selection and rotation, and safe sharps disposal. All nurses are ANM/GNM certified." },
      { question: "Can you provide regular injection services on a daily basis?", answer: "Yes, we offer daily, alternate-day, and weekly injection schedules for patients who need ongoing therapy such as insulin or blood thinners. We also provide medication reminders and adherence tracking." },
    ],
  },
  {
    slug: "enema",
    title: "Enema Administration",
    shortTitle: "Enema",
    description: "Professional enema administration service at home in Hyderabad. Our trained nurses perform safe, hygienic enema procedures for constipation relief, bowel preparation, or as prescribed by your doctor.",
    icon: "Waves",
    originalCost: "₹698",
    baselineCost: "₹349",
    discount: "50% OFF",
    faqs: [
      { question: "What is an enema and when is it needed?", answer: "An enema is a procedure where a liquid solution is gently introduced into the rectum to stimulate bowel movement. It is commonly used for severe constipation relief, bowel preparation before medical procedures, or as part of a doctor-prescribed treatment plan." },
      { question: "Is enema administration at home safe?", answer: "Yes, when performed by a trained nurse. Our nurses follow proper technique including correct solution preparation, temperature check, safe administration, and patient positioning to ensure comfort and effectiveness. A doctor's prescription or advice is recommended." },
      { question: "What type of enema solutions are used?", answer: "Common enema solutions include normal saline, tap water, or medicated solutions as prescribed by your doctor. The family should arrange the prescribed solution; our nurse will guide you on what to keep ready." },
      { question: "How quickly does an enema work?", answer: "An enema typically produces a bowel movement within 5-15 minutes after administration. Our nurse will stay with the patient until the procedure is complete and ensure the patient is comfortable." },
    ],
  },
  {
    slug: "suture-staple-removal",
    title: "Suture & Staple Removal",
    shortTitle: "Suture Removal",
    description: "Professional suture and staple removal service at home in Hyderabad. Our experienced nurses safely remove surgical stitches and staples after wound healing, following your surgeon's instructions.",
    icon: "Scissors",
    originalCost: "₹698",
    baselineCost: "₹349",
    discount: "50% OFF",
    faqs: [
      { question: "When should sutures or staples be removed?", answer: "Removal timing depends on the surgery and wound location. Typically, facial sutures are removed in 5-7 days, body sutures in 7-14 days, and sutures over joints in 14-21 days. Your surgeon will specify the exact date for removal." },
      { question: "Is suture removal at home safe?", answer: "Yes. Our nurses are trained in suture and staple removal techniques. The procedure is quick and involves cutting and gently pulling out each stitch or staple. The nurse will also assess wound healing and advise if any concerns need surgeon attention." },
      { question: "Does suture or staple removal hurt?", answer: "Most patients feel only a mild pulling sensation. There may be slight discomfort but it is generally well-tolerated. Our nurses are gentle and experienced in minimizing discomfort during the procedure." },
      { question: "Do I need a doctor's instruction for suture removal?", answer: "Yes, your surgeon's written instruction specifying the date and details for suture/staple removal is required. This ensures the wound has healed sufficiently for safe removal." },
    ],
  },
  {
    slug: "grbs",
    title: "General Random Blood Sugar (GRBS) Test",
    shortTitle: "GRBS Test",
    description: "Quick General Random Blood Sugar (GRBS) testing at home in Hyderabad. Our nurses perform fingertip blood sugar checks using calibrated glucometers, providing instant readings for diabetes monitoring and management.",
    icon: "HeartPulse",
    originalCost: "₹498",
    baselineCost: "₹249",
    discount: "50% OFF",
    faqs: [
      { question: "What is a GRBS test?", answer: "GRBS (General Random Blood Sugar) is a blood glucose test that can be done at any time of day, regardless of when you last ate. It provides a snapshot of your current blood sugar level and is useful for monitoring diabetes, checking for hypoglycemia or hyperglycemia, and tracking treatment effectiveness." },
      { question: "How is the GRBS test performed at home?", answer: "Our nurse performs a quick fingertip prick using a sterile lancet, collects a small blood drop on a test strip, and gets an instant reading on a calibrated digital glucometer. The entire process takes less than 2 minutes." },
      { question: "What is a normal GRBS reading?", answer: "A normal random blood sugar level is typically below 200 mg/dL. Readings above 200 mg/dL may indicate diabetes, while readings below 70 mg/dL may indicate hypoglycemia. However, only your doctor can make a proper diagnosis based on comprehensive evaluation." },
      { question: "Can the GRBS test be combined with other services?", answer: "Yes, GRBS testing is often combined with vitals checking, injection administration, or as part of comprehensive home nursing care. We offer flexible visit-based packages." },
    ],
  },
  {
    slug: "colostomy-bag-change",
    title: "Colostomy Bag Change",
    shortTitle: "Colostomy Care",
    description: "Professional colostomy bag change and stoma care service at home in Hyderabad. Our trained nurses provide hygienic colostomy bag replacement, peristomal skin care, and caregiver education for ostomy patients.",
    icon: "RefreshCw",
    originalCost: "₹998",
    baselineCost: "₹499",
    discount: "50% OFF",
    faqs: [
      { question: "What does a colostomy bag change at home involve?", answer: "Our nurse removes the used colostomy bag, cleans the stoma and surrounding skin with appropriate solutions, assesses the stoma for any issues, applies a new skin barrier/wafer, and fits a fresh colostomy bag securely. The nurse also checks for leaks and ensures a proper seal." },
      { question: "How often should a colostomy bag be changed?", answer: "Typically, a colostomy bag should be changed every 3-7 days or whenever it is one-third full, whichever comes first. Drainable bags may be emptied multiple times daily and replaced on a schedule. Your nurse will recommend the best schedule based on your specific needs." },
      { question: "Is colostomy care at home safe and hygienic?", answer: "Absolutely. Our nurses follow strict infection control protocols using sterile techniques, proper disposal of waste, and thorough hand hygiene. They ensure the stoma site remains clean, dry, and free from irritation." },
      { question: "Do you train family members on colostomy care?", answer: "Yes, we provide hands-on caregiver training for colostomy bag changes. Our nurses teach proper technique, skin care, bag fitting, troubleshooting leaks, and when to seek medical help. Training typically takes 2-3 sessions." },
    ],
  },
];

export function getMedicalOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "MedicalOrganization",
    name: BUSINESS.name,
    url: BUSINESS.url,
    logo: BUSINESS.logo,
    telephone: BUSINESS.phone,
    email: BUSINESS.email,
    address: { "@type": "PostalAddress", ...BUSINESS.address },
    geo: { "@type": "GeoCoordinates", latitude: BUSINESS.geo.latitude, longitude: BUSINESS.geo.longitude },
    openingHoursSpecification: { "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"], opens: "00:00", closes: "23:59" },
    priceRange: BUSINESS.priceRange,
    areaServed: { "@type": "City", name: "Hyderabad", containedInPlace: { "@type": "State", name: "Telangana" } },
    sameAs: ["https://www.facebook.com/carefirsthyd","https://www.instagram.com/carefirsthyd","https://twitter.com/carefirsthyd"],
    aggregateRating: { "@type": "AggregateRating", ratingValue: "4.8", reviewCount: "342", bestRating: "5" },
  };
}

export function getFAQSchema(faqs: Array<{ question: string; answer: string }>) {
  return { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } })) };
}

export function getServiceSchema(service: (typeof SERVICES)[number]) {
  return { "@context": "https://schema.org", "@type": "MedicalTherapy", name: service.title, description: service.description, url: `${BUSINESS.url}/services/${service.slug}`, provider: { "@type": "MedicalOrganization", name: BUSINESS.name, url: BUSINESS.url }, areaServed: { "@type": "City", name: "Hyderabad", containedInPlace: { "@type": "State", name: "Telangana" } } };
}

export function trackWhatsAppClick() {
  if (typeof window !== "undefined" && (window as unknown as Record<string, unknown>).dataLayer) {
    (window as unknown as { dataLayer: Array<Record<string, string>> }).dataLayer.push({ event: "whatsapp_click", event_category: "CTA", event_label: "WhatsApp Link Click" });
  }
}

export function trackPhoneCallClick() {
  if (typeof window !== "undefined" && (window as unknown as Record<string, unknown>).dataLayer) {
    (window as unknown as { dataLayer: Array<Record<string, string>> }).dataLayer.push({ event: "phone_call_click", event_category: "CTA", event_label: "Phone Call Click" });
  }
}

export function trackFormSubmission(formData: { name: string; phone: string; careType: string }) {
  if (typeof window !== "undefined" && (window as unknown as Record<string, unknown>).dataLayer) {
    (window as unknown as { dataLayer: Array<Record<string, string | object>> }).dataLayer.push({ event: "form_submission", event_category: "Lead", event_label: "Home Page Lead Form", form_data: formData });
  }
}
