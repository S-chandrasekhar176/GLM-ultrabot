"use client";

import { useState, useCallback } from "react";
import { Header } from "@/components/homecare/header";
import { HeroSection } from "@/components/homecare/hero-section";
import { TrustSection } from "@/components/homecare/trust-section";
import { ServicesSection } from "@/components/homecare/services-section";
import { ComparisonSection } from "@/components/homecare/comparison-section";
import { ServicePageTemplate } from "@/components/homecare/service-page-template";
import { Footer } from "@/components/homecare/footer";
import { MobileBottomBar } from "@/components/homecare/mobile-bottom-bar";
import { BUSINESS, trackWhatsAppClick, trackPhoneCallClick, PROMO_CODE } from "@/lib/seo-data";
import { MessageCircle, Phone, Users, CheckCircle2, Clock, MapPin, Tag, X } from "lucide-react";

export default function Home() {
  const [currentView, setCurrentView] = useState("home");
  const [activeService, setActiveService] = useState<string | null>(null);
  const [showPromoBanner, setShowPromoBanner] = useState(true);
  const [promoApplied, setPromoApplied] = useState(false);

  const handlePromoApply = useCallback((applied: boolean) => {
    setPromoApplied(applied);
  }, []);

  const handleNavigate = useCallback((view: string, serviceSlug?: string) => {
    if (view === "service" && serviceSlug) {
      setActiveService(serviceSlug);
      setCurrentView("service");
    } else {
      setCurrentView("home");
      setActiveService(null);
    }
  }, []);

  const handleServiceClick = useCallback((slug: string) => {
    setActiveService(slug);
    setCurrentView("service");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const handleBackToHome = useCallback(() => {
    setCurrentView("home");
    setActiveService(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header onNavigate={handleNavigate} currentView={currentView} />

      {currentView === "service" && activeService ? (
        <ServicePageTemplate serviceSlug={activeService} onBack={handleBackToHome} promoApplied={promoApplied} onPromoApply={handlePromoApply} />
      ) : (
        <>
          {/* HERO - Above the Fold with Lead Form */}
          <HeroSection onPromoApply={handlePromoApply} promoApplied={promoApplied} />

          {/* ABOUT / WHY CHOOSE US */}
          <section className="py-20 sm:py-24" aria-label="Why choose us">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-14">
                <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">Why Choose Us</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-4">
                  Why Families Choose CareFirst for Home Nursing in Hyderabad
                </h2>
                <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
                  Every aspect of our service is designed around patient safety, clinical excellence, and family peace of mind.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {[
                  {
                    Icon: Users,
                    title: "100% Verified Caregivers",
                    desc: "Every nurse undergoes a 7-point background check including police verification, TS Nurses Council registration, and credential authentication. No exceptions.",
                  },
                  {
                    Icon: CheckCircle2,
                    title: "RN/ANM Certified Staff",
                    desc: "All caregivers hold valid Registered Nurse (RN) or Auxiliary Nurse Midwife (ANM) certifications from recognized Indian nursing councils with regular skill upgradation.",
                  },
                  {
                    Icon: Clock,
                    title: "24/7 Rapid Deployment",
                    desc: "Need a nurse urgently? Our Hyderabad-based team can deploy a trained caregiver to your doorstep within 15 minutes to 1 hour for emergency situations, any time of day or night.",
                  },
                  {
                    Icon: MapPin,
                    title: "Pan-Hyderabad Coverage",
                    desc: "From Jubilee Hills to Miyapur, Gachibowli to Secunderabad — we cover all major areas in Hyderabad and surrounding Telangana regions with local nurses.",
                  },
                  {
                    Icon: Phone,
                    title: "Dedicated Care Coordinator",
                    desc: "Each family is assigned a dedicated care coordinator who serves as your single point of contact for scheduling, nurse replacement, and doctor coordination.",
                  },
                  {
                    Icon: Tag,
                    title: "Transparent Pricing",
                    desc: "No hidden charges. Get a clear cost breakdown before care begins. Use code START50 for 50% off on your first booking. Pay only for what you need.",
                  },
                ].map(({ Icon, title, desc }, idx) => (
                  <div
                    key={title}
                    className={`premium-card p-6 opacity-0 animate-fade-in-up stagger-${idx + 1}`}
                  >
                    <div className="w-11 h-11 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl flex items-center justify-center mb-3.5">
                      <Icon className="w-5 h-5 text-emerald-700" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* PROMO BANNER - Premium */}
          {showPromoBanner && (
            <section className="relative bg-gradient-to-r from-red-600 via-red-600 to-rose-600 py-4 px-4 shadow-md shadow-red-200" aria-label="Promotional offer">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent" />
              <div className="relative max-w-7xl mx-auto flex items-center justify-center gap-4 flex-wrap">
                <span className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm px-4 py-1.5 rounded-full text-white text-sm font-black animate-promo-pulse border border-white/20">
                  50% OFF — Limited Time Offer
                </span>
                <span className="text-white/90 text-sm sm:text-base font-semibold">
                  Use promo code <span className="bg-white/20 text-white px-2.5 py-0.5 rounded-md font-black tracking-[0.15em] text-sm mx-1 border border-white/15">{PROMO_CODE}</span> for half-price home nursing
                </span>
              </div>
              <button
                onClick={() => setShowPromoBanner(false)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors p-1"
                aria-label="Close promotional banner"
              >
                <X className="w-4 h-4" />
              </button>
            </section>
          )}

          {/* SERVICES GRID */}
          <ServicesSection onServiceClick={handleServiceClick} promoApplied={promoApplied} />

          {/* COMPARISON: Others vs CareFirst */}
          <ComparisonSection />

          {/* TRUST / E-E-A-T SECTION */}
          <TrustSection />

          {/* CTA BANNER - Premium */ }
          <section className="py-16 sm:py-20 relative overflow-hidden" aria-label="Call to action">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900" />
            <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }} />
            <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <h2 className="text-2xl sm:text-3xl font-extrabold mb-4 text-white">
                Your Loved One Deserves the Best Care at Home
              </h2>
              <p className="text-emerald-200/80 text-lg mb-10 max-w-2xl mx-auto leading-relaxed">
                Whether it is post-surgical recovery, critical care nursing, or 24/7 home support, our expert nursing team in Hyderabad is ready to help. Book your care today.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <a
                  href={`tel:${BUSINESS.phoneRaw}`}
                  onClick={() => trackPhoneCallClick()}
                  className="inline-flex items-center gap-2.5 px-8 py-4 bg-white text-emerald-900 font-bold text-lg rounded-xl hover:bg-gray-50 transition-all duration-300 shadow-xl hover:-translate-y-0.5"
                >
                  <Phone className="w-5 h-5" />
                  Speak with Our Expert
                </a>
                <a
                  href={BUSINESS.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackWhatsAppClick()}
                  className="inline-flex items-center gap-2.5 px-8 py-4 bg-[#25D366] hover:bg-[#1da851] text-white font-bold text-lg rounded-xl transition-all duration-300 shadow-lg shadow-green-500/25 hover:-translate-y-0.5"
                >
                  <MessageCircle className="w-5 h-5" />
                  WhatsApp Now
                </a>
              </div>
            </div>
          </section>
        </>
      )}

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
