import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { GTMScripts } from "@/components/homecare/gtm-scripts";
import { getMedicalOrganizationSchema, BUSINESS } from "@/lib/seo-data";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "CareFirst Home Nursing Services Hyderabad | Trusted Elder Care",
  description:
    "Get trusted nursing homecare in Hyderabad. 24/7 elder care, post-surgical care, injections, wound care & more by certified nurses. Call now!",
  keywords: [
    "nursing homecare in Hyderabad",
    "elder care services Hyderabad",
    "home nursing services Telangana",
    "senior citizen caretaker Hyderabad",
    "ICU setup at home Hyderabad",
    "bedridden patient support",
    "dementia care assistance",
    "post-surgical nursing care",
    "mother and baby care Hyderabad",
    "home nurse Hyderabad",
    "24/7 nursing care",
    "attender services Hyderabad",
    "patient care services",
    "certified home nurses",
    "healthcare at home",
  ],
  authors: [{ name: BUSINESS.name }],
  creator: BUSINESS.name,
  publisher: BUSINESS.name,
  metadataBase: new URL(BUSINESS.url),
  alternates: {
    canonical: "/",
    languages: {
      "en-IN": "/",
      "te-IN": "/te/",
      "hi-IN": "/hi/",
      "x-default": "/",
    },
  },
  openGraph: {
    title: "CareFirst Home Nursing Services Hyderabad | Trusted Elder Care",
    description:
      "Get trusted nursing homecare in Hyderabad. 24/7 elder care, post-surgical care, injections, wound care & more by certified nurses. Call now!",
    url: BUSINESS.url,
    siteName: BUSINESS.name,
    locale: "en_IN",
    type: "website",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "CareFirst Home Nursing Services - Trusted Nursing Care in Hyderabad",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Nursing Homecare in Hyderabad | CareFirst",
    description:
      "24/7 home nursing, elder care, injections, wound care & more by certified nurses. Book now!",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const medicalOrgSchema = getMedicalOrganizationSchema();

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Hreflang Tags for Multilingual Readiness */}
        <link rel="alternate" hrefLang="en-IN" href="/" />
        <link rel="alternate" hrefLang="te-IN" href="/te/" />
        <link rel="alternate" hrefLang="hi-IN" href="/hi/" />
        <link rel="alternate" hrefLang="x-default" href="/" />
        {/* Preconnect to WhatsApp for faster redirect */}
        <link rel="preconnect" href="https://wa.me" />
        {/* JSON-LD: MedicalOrganization Schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(medicalOrgSchema),
          }}
        />
      </head>
      <body
        className={`${inter.variable} font-sans antialiased bg-background text-foreground`}
      >
        {/* GTM NoScript Fallback */}
        <noscript>
          <iframe
            src={`https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX`}
            height="0"
            width="0"
            style={{ display: "none", visibility: "hidden" }}
            title="GTM"
          />
        </noscript>
        <GTMScripts />
        {children}
        <Toaster />
      </body>
    </html>
  );
}
