import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// POST: Submit a new review
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, rating, text, service, postToGoogle } = body;

    if (!name?.trim() || !rating || !text?.trim()) {
      return NextResponse.json(
        { error: "Name, rating, and review text are required." },
        { status: 400 }
      );
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json(
        { error: "Rating must be between 1 and 5." },
        { status: 400 }
      );
    }

    if (text.trim().length < 10) {
      return NextResponse.json(
        { error: "Review must be at least 10 characters." },
        { status: 400 }
      );
    }

    const review = await prisma.review.create({
      data: {
        name: name.trim(),
        rating,
        text: text.trim(),
        service: service?.trim() || null,
        approved: false,
        postedToGoogle: postToGoogle || false,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Thank you! Your review has been submitted and will appear after approval.",
        review: {
          id: review.id,
          name: review.name,
          rating: review.rating,
          text: review.text,
          service: review.service,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Review submission error:", error);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}

// GET: Fetch approved reviews
export async function GET() {
  try {
    const reviews = await prisma.review.findMany({
      where: { approved: true },
      orderBy: { createdAt: "desc" },
      take: 20,
    });

    return NextResponse.json({ reviews });
  } catch (error) {
    console.error("Review fetch error:", error);
    return NextResponse.json(
      { error: "Failed to fetch reviews." },
      { status: 500 }
    );
  }
}
