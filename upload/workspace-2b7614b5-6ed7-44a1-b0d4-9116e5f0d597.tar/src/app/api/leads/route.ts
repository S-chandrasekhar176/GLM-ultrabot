import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, careType, page, promoCode } = body;

    if (!name || !phone || !careType) {
      return NextResponse.json(
        { error: "Name, phone, and careType are required." },
        { status: 400 }
      );
    }

    const lead = await db.lead.create({
      data: {
        name,
        phone,
        careType,
        page: page || "home",
        source: "website",
        status: "new",
        dpdpConsent: true,
        promoCode: promoCode || "",
      },
    });

    // ============================================================
    // NOTIFICATION HOOKS — Uncomment and configure options below
    // to receive real-time notifications on every new lead.
    // ============================================================

    // OPTION 1: WhatsApp Notification (via Twilio)
    // Install: bun add twilio
    // Env vars: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN
    //
    // import Twilio from 'twilio';
    // const twilio = Twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    // await twilio.messages.create({
    //   body: `New Lead! ${name} | ${phone} | ${careType}`,
    //   from: 'whatsapp:+14155238886',
    //   to: 'whatsapp:+9198XXXXXXXX',
    // });

    // OPTION 2: SMS to your phone (via Twilio)
    // Install: bun add twilio
    // Env vars: TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER
    //
    // const twilio = Twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    // await twilio.messages.create({
    //   body: `[NEW LEAD] ${name} | ${phone} | ${careType}`,
    //   from: process.env.TWILIO_PHONE_NUMBER,
    //   to: '+9198XXXXXXXX',
    // });

    // OPTION 3: Email Notification (via Resend)
    // Install: bun add resend
    // Env vars: RESEND_API_KEY, YOUR_EMAIL
    //
    // import { Resend } from 'resend';
    // const resend = new Resend(process.env.RESEND_API_KEY);
    // await resend.emails.send({
    //   from: 'leads@yourdomain.com',
    //   to: process.env.YOUR_EMAIL!,
    //   subject: `New Lead: ${name} - ${careType}`,
    //   html: `<p><b>Name:</b> ${name}</p><p><b>Phone:</b> ${phone}</p><p><b>Care:</b> ${careType}</p><p><b>Time:</b> ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>`,
    // });

    // OPTION 4: Google Sheets logging
    // Install: bun add google-sheets
    // Env vars: GOOGLE_SERVICE_ACCOUNT_EMAIL, GOOGLE_PRIVATE_KEY, SHEET_ID

    // OPTION 5: Zapier / Make.com Webhook
    //
    // await fetch('https://hooks.zapier.com/hooks/catch/YOUR_WEBHOOK_ID/', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ name, phone, careType, submittedAt: new Date().toISOString() }),
    // });

    return NextResponse.json({ success: true, leadId: lead.id }, { status: 201 });
  } catch (error) {
    console.error("Lead submission error:", error);
    return NextResponse.json(
      { error: "Failed to submit lead. Please try again." },
      { status: 500 }
    );
  }
}

// GET: list recent leads (admin use)
export async function GET() {
  try {
    const leads = await db.lead.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json({ leads });
  } catch {
    return NextResponse.json({ error: "Failed to fetch leads." }, { status: 500 });
  }
}
