import { SERVICES } from "@/lib/seo-data";
import { Heart, Activity, ShieldCheck, BedDouble, Brain, Baby, Syringe, Bandage, Thermometer, Pill, Droplets, RotateCcw, FlaskConical, PenLine, Crosshair, Waves, Scissors, HeartPulse, RefreshCw, Sparkles } from "lucide-react";

const ICON_MAP: Record<string, React.ElementType> = {
  Heart, Activity, ShieldCheck, BedDouble, Brain, Baby, Syringe, Bandage, Thermometer,
  Pill, Droplets, RotateCcw, FlaskConical, PenLine, Crosshair, Waves, Scissors, HeartPulse, RefreshCw,
};

function getIcon(name: string) {
  return ICON_MAP[name] || Heart;
}

interface ServicesSectionProps {
  onServiceClick: (slug: string) => void;
  promoApplied: boolean;
}

export function ServicesSection({ onServiceClick, promoApplied }: ServicesSectionProps) {
  return (
    <section className="py-20 sm:py-24" aria-label="Our services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">
            Our Services
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-4">
            Complete Home Healthcare Services in Hyderabad
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            From injection services and wound care to critical care nursing — comprehensive, professional care tailored to every patient&apos;s needs.
          </p>
          {promoApplied && (
            <div className="mt-4 inline-flex items-center gap-2 bg-gradient-to-r from-red-500 to-red-600 text-white px-5 py-2 rounded-full text-sm font-bold shadow-lg shadow-red-200">
              <Sparkles className="w-4 h-4" />
              50% OFF Applied on All Services!
            </div>
          )}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((service, idx) => {
            const Icon = getIcon(service.icon);
            return (
              <button
                key={service.slug}
                onClick={() => onServiceClick(service.slug)}
                className={`premium-card group text-left p-6 focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 opacity-0 animate-fade-in-up stagger-${(idx % 9) + 1}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl flex items-center justify-center group-hover:from-emerald-100 group-hover:to-emerald-200 transition-colors">
                    <Icon className="w-6 h-6 text-emerald-700" />
                  </div>
                  {promoApplied && (
                    <span className="inline-flex items-center px-2.5 py-1 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-bold rounded-full shadow-sm shadow-red-200">
                      50% OFF
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-emerald-800 transition-colors">
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                  {service.description.slice(0, 110)}...
                </p>
                <div className="flex items-end justify-between pt-4 border-t border-gray-50">
                  <div>
                    {promoApplied ? (
                      <>
                        <span className="block text-sm text-muted-foreground line-through font-medium">{service.originalCost}</span>
                        <span className="block text-lg font-extrabold text-emerald-700">{service.baselineCost}/-</span>
                      </>
                    ) : (
                      <>
                        <span className="block text-lg font-extrabold text-gray-900">Starting from {service.originalCost}/-</span>
                      </>
                    )}
                  </div>
                  <span className="text-sm font-semibold text-emerald-600 group-hover:translate-x-1.5 transition-transform duration-300">
                    Details &rarr;
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
