"use client";

import { useState, useEffect } from "react";
import { BadgeCheck, Star, Quote, Stethoscope } from "lucide-react";
import { ReviewForm } from "./review-form";

const SPECIALIST = {
  name: "Swathi V",
  title: "Senior Nursing Specialist",
  credentials: "B.Sc. Nursing, ICU Trained",
  experience: "12+ years experience",
  description: "Specialized in critical care nursing, post-surgical recovery, and complex home care management. Leads our clinical team with expertise in ICU protocols, wound care, and patient-centered nursing care at home.",
};

const DEFAULT_REVIEWS = [
  { name: "Rajesh K.", rating: 5, text: "Excellent home nursing services. The nurse assigned was very professional and caring. Highly recommend CareFirst for nursing care in Hyderabad.", time: "2 weeks ago" },
  { name: "Lakshmi P.", rating: 5, text: "We used their critical care nursing service after surgery. The nursing care was hospital-grade. Very grateful for the team.", time: "1 month ago" },
  { name: "Srinivas M.", rating: 4, text: "Good post-surgical care. The nurse was punctual and followed all instructions from the doctor. Would definitely use their services again.", time: "2 months ago" },
  { name: "Anitha R.", rating: 5, text: "The care team was incredibly patient and well-trained. They helped us understand the condition better and provided excellent support.", time: "3 months ago" },
];

interface UserReview {
  id: string;
  name: string;
  rating: number;
  text: string;
  service?: string | null;
  createdAt: string;
}

export function TrustSection() {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [userReviews, setUserReviews] = useState<UserReview[]>([]);

  useEffect(() => {
    fetch("/api/reviews")
      .then((res) => res.json())
      .then((data) => setUserReviews(data.reviews || []))
      .catch(() => {});
  }, []);

  const allReviews = [
    ...userReviews.map((r) => ({
      name: r.name,
      rating: r.rating,
      text: r.text,
      time: new Date(r.createdAt).toLocaleDateString("en-IN", { month: "short", year: "numeric" }),
    })),
    ...DEFAULT_REVIEWS,
  ];

  return (
    <section className="py-20 sm:py-24 bg-gray-50/80" aria-label="Trust signals and care team">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">Trust & Expertise</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-4">
            Why Hyderabad Trusts CareFirst
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Uncompromising medical standards, verified professionals, and hundreds of satisfied families across Telangana.
          </p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-16">
          {[
            { value: "1,200+", label: "Families Served" },
            { value: "350+", label: "Verified Nurses" },
            { value: "4.8/5", label: "Google Rating" },
            { value: "7+", label: "Years of Service" },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-5 sm:p-6 bg-white rounded-2xl shadow-sm border border-gray-100">
              <div className="text-3xl sm:text-4xl font-black text-emerald-700 mb-1.5 tracking-tight">{stat.value}</div>
              <div className="text-sm text-muted-foreground font-semibold">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Meet Our Senior Nursing Specialist - Single Profile */}
        <div className="mb-16">
          <h3 className="text-xl sm:text-2xl font-extrabold text-gray-900 text-center mb-10">
            Meet Our Senior Nursing Specialist
          </h3>
          <div className="max-w-md mx-auto">
            <article className="premium-card bg-emerald-50 p-8 text-center opacity-0 animate-fade-in-up stagger-1">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-lg">
                <Stethoscope className="w-10 h-10 text-white" />
              </div>
              <h4 className="text-xl font-extrabold text-gray-900 mb-1">{SPECIALIST.name}</h4>
              <p className="text-sm font-bold text-emerald-700 mb-1">{SPECIALIST.title}</p>
              <p className="text-xs text-muted-foreground mb-0.5">{SPECIALIST.credentials}</p>
              <p className="text-xs text-muted-foreground font-medium mb-3">{SPECIALIST.experience}</p>
              <p className="text-sm text-gray-600 leading-relaxed">{SPECIALIST.description}</p>
            </article>
          </div>
          <p className="text-center mt-8 text-sm font-bold text-emerald-800 bg-emerald-50 inline-block px-5 py-2.5 rounded-full mx-auto border border-emerald-200">
            100% RN/ANM Certified Nursing Staff
          </p>
        </div>

        {/* Reviews Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <div className="flex items-center gap-2.5">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-amber-500" fill="#f59e0b" />
                ))}
              </div>
              <h3 className="text-lg font-extrabold text-gray-900">Google Reviews</h3>
              <span className="text-sm text-muted-foreground font-medium">(342 reviews, 4.8 avg)</span>
            </div>
            <button
              onClick={() => setShowReviewForm(!showReviewForm)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-sm font-bold rounded-xl transition-all duration-200 shadow-sm"
            >
              <BadgeCheck className="w-4 h-4" />
              {showReviewForm ? "View Reviews" : "Write a Review"}
            </button>
          </div>

          {showReviewForm ? (
            <div className="max-w-lg mx-auto">
              <ReviewForm />
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-xl border border-gray-100">
              <div className="grid md:grid-cols-2 gap-4">
                {allReviews.map((review, idx) => (
                  <div key={idx} className="flex gap-3 p-4 bg-gray-50/80 rounded-xl border border-gray-100">
                    <Quote className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="font-bold text-sm text-gray-900">{review.name}</span>
                        <span className="text-xs text-muted-foreground">{review.time}</span>
                      </div>
                      <div className="flex gap-0.5 mb-2">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} className={`w-3.5 h-3.5 ${i < review.rating ? "text-amber-500" : "text-gray-200"}`} fill={i < review.rating ? "f59e0b" : "none"} />
                        ))}
                      </div>
                      <p className="text-sm text-gray-600 leading-relaxed">{review.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
