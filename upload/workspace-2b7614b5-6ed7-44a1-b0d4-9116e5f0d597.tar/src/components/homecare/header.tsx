"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { BUSINESS, SERVICES, trackPhoneCallClick } from "@/lib/seo-data";
import { Phone, Menu, X, Heart, ChevronDown, FileText, Users, BookOpen, Mail, Home, Activity, ShieldCheck, BedDouble, Brain, Baby, Syringe, Bandage, Thermometer, Pill, Droplets, RotateCcw, FlaskConical, PenLine, Crosshair, Waves, Scissors, HeartPulse, RefreshCw } from "lucide-react";

interface HeaderProps {
  onNavigate: (view: string, serviceSlug?: string) => void;
  currentView: string;
}

export function Header({ onNavigate, currentView }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesDropdown, setServicesDropdown] = useState(false);

  const handleNavClick = (view: string, serviceSlug?: string) => {
    onNavigate(view, serviceSlug);
    setMobileOpen(false);
    setServicesDropdown(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-xl border-b border-gray-100 shadow-[0_1px_12px_rgba(0,0,0,0.05)]">
      {/* Top info bar - hidden on mobile */}
      <div className="hidden md:block bg-gradient-to-r from-emerald-900 to-emerald-800 text-white text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-10">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              {BUSINESS.email}
            </span>
            <span>Hyderabad, Telangana</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
            </span>
            <span className="text-xs font-bold tracking-widest uppercase">Available 24/7 for Emergencies</span>
          </div>
        </div>
      </div>

      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => handleNavClick("home")}
            className="flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-md"
            aria-label="Go to Home"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-xl flex items-center justify-center shadow-md shadow-emerald-200">
              <Heart className="w-5 h-5 text-white" fill="white" />
            </div>
            <div className="hidden sm:block">
              <span className="block text-lg font-extrabold text-gray-900 leading-tight">
                CareFirst
              </span>
              <span className="block text-xs text-muted-foreground leading-tight font-medium">
                Home Nursing Services
              </span>
            </div>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => handleNavClick("home")}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentView === "home"
                  ? "bg-emerald-50 text-emerald-800"
                  : "text-gray-700 hover:bg-gray-50 hover:text-emerald-800"
              }`}
            >
              Home
            </button>

            {/* Services Mega Menu Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setServicesDropdown(true)}
              onMouseLeave={() => setServicesDropdown(false)}
            >
              <button
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1 ${
                  currentView === "service"
                    ? "bg-emerald-50 text-emerald-800"
                    : "text-gray-700 hover:bg-gray-50 hover:text-emerald-800"
                }`}
                aria-expanded={servicesDropdown}
                aria-haspopup="true"
              >
                Services
                <ChevronDown
                  className={`w-4 h-4 transition-transform duration-200 ${
                    servicesDropdown ? "rotate-180" : ""
                  }`}
                />
              </button>
              {servicesDropdown && (
                <div className="absolute top-full -left-32 w-[720px] bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden">
                  {/* Top accent line */}
                  <div className="h-1 bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-500" />
                  <div className="p-6 grid grid-cols-3 gap-6">
                    {/* Column 1: Home Nursing Care */}
                    <div>
                      <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-[0.15em] mb-3">Home Nursing Care</h4>
                      <ul className="space-y-0.5">
                        {[
                          { s: SERVICES[0], Icon: Heart },
                          { s: SERVICES[1], Icon: Activity },
                          { s: SERVICES[2], Icon: ShieldCheck },
                          { s: SERVICES[3], Icon: BedDouble },
                          { s: SERVICES[4], Icon: Brain },
                          { s: SERVICES[5], Icon: Baby },
                        ].map(({ s, Icon }) => (
                          <li key={s.slug}>
                            <button
                              onClick={() => handleNavClick("service", s.slug)}
                              className="w-full text-left px-3 py-2 rounded-lg text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors flex items-center gap-2.5 group"
                            >
                              <Icon className="w-3.5 h-3.5 text-gray-300 group-hover:text-emerald-500 transition-colors flex-shrink-0" />
                              {s.shortTitle}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Column 2: Clinical Procedures */}
                    <div>
                      <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-[0.15em] mb-3">Clinical Procedures</h4>
                      <ul className="space-y-0.5">
                        {[
                          { s: SERVICES[9], Icon: Pill },
                          { s: SERVICES[10], Icon: Droplets },
                          { s: SERVICES[11], Icon: RotateCcw },
                          { s: SERVICES[12], Icon: FlaskConical },
                          { s: SERVICES[13], Icon: PenLine },
                          { s: SERVICES[15], Icon: Waves },
                          { s: SERVICES[16], Icon: Scissors },
                        ].map(({ s, Icon }) => (
                          <li key={s.slug}>
                            <button
                              onClick={() => handleNavClick("service", s.slug)}
                              className="w-full text-left px-3 py-2 rounded-lg text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors flex items-center gap-2.5 group"
                            >
                              <Icon className="w-3.5 h-3.5 text-gray-300 group-hover:text-emerald-500 transition-colors flex-shrink-0" />
                              {s.shortTitle}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Column 3: Injections & Monitoring */}
                    <div>
                      <h4 className="text-[11px] font-bold text-muted-foreground uppercase tracking-[0.15em] mb-3">Injections & Monitoring</h4>
                      <ul className="space-y-0.5">
                        {[
                          { s: SERVICES[6], Icon: Syringe },
                          { s: SERVICES[14], Icon: Crosshair },
                          { s: SERVICES[7], Icon: Bandage },
                          { s: SERVICES[8], Icon: Thermometer },
                          { s: SERVICES[17], Icon: HeartPulse },
                          { s: SERVICES[18], Icon: RefreshCw },
                        ].map(({ s, Icon }) => (
                          <li key={s.slug}>
                            <button
                              onClick={() => handleNavClick("service", s.slug)}
                              className="w-full text-left px-3 py-2 rounded-lg text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors flex items-center gap-2.5 group"
                            >
                              <Icon className="w-3.5 h-3.5 text-gray-300 group-hover:text-emerald-500 transition-colors flex-shrink-0" />
                              {s.shortTitle}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Bottom bar with CTA */}
                  <div className="px-6 py-3.5 bg-gray-50/80 border-t border-gray-100 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground font-medium">19 services covering all your home nursing needs</span>
                    <button
                      onClick={() => handleNavClick("home")}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-900 transition-colors flex items-center gap-1"
                    >
                      View All Services
                      <ChevronDown className="w-3 h-3 rotate-[-90deg]" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNavClick("home")}
              className="px-3 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-emerald-800 transition-colors"
            >
              About Us
            </button>

            <button
              onClick={() => handleNavClick("home")}
              className="px-3 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-emerald-800 transition-colors"
            >
              Health Hub
            </button>

            <button
              onClick={() => handleNavClick("home")}
              className="px-3 py-2 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-emerald-800 transition-colors"
            >
              Contact Us
            </button>
          </div>

          {/* Phone CTA - Desktop */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={`tel:${BUSINESS.phoneRaw}`}
              onClick={() => trackPhoneCallClick()}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-700 to-emerald-800 hover:from-emerald-800 hover:to-emerald-900 text-white rounded-xl text-sm font-bold transition-all duration-200 shadow-sm shadow-emerald-200 focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2"
            >
              <Phone className="w-4 h-4" />
              Contact Our Expert
            </a>
          </div>

          {/* Mobile Hamburger */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <button
                className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors focus-visible:ring-2 focus-visible:ring-primary"
                aria-label="Open navigation menu"
              >
                <Menu className="w-6 h-6 text-gray-700" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 sm:w-96 p-0">
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <div className="flex flex-col h-full">
                {/* Mobile Header */}
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-emerald-700 rounded-lg flex items-center justify-center">
                      <Heart className="w-4 h-4 text-white" fill="white" />
                    </div>
                    <span className="font-bold text-emerald-900">CareFirst</span>
                  </div>
                  <button
                    onClick={() => setMobileOpen(false)}
                    aria-label="Close menu"
                    className="p-2 rounded-lg hover:bg-gray-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Mobile Nav Links */}
                <div className="flex-1 overflow-y-auto py-4">
                  <button
                    onClick={() => handleNavClick("home")}
                    className={`w-full text-left px-6 py-3 text-base font-medium ${
                      currentView === "home"
                        ? "bg-emerald-50 text-emerald-800 border-r-4 border-emerald-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    Home
                  </button>

                  {/* Categorized Services - Mobile */}
                  <div className="px-6 py-2">
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Home Nursing Care
                    </span>
                  </div>
                  {[SERVICES[0], SERVICES[1], SERVICES[2], SERVICES[3], SERVICES[4], SERVICES[5]].map((s) => (
                    <button
                      key={s.slug}
                      onClick={() => handleNavClick("service", s.slug)}
                      className={`w-full text-left pl-10 pr-6 py-2.5 text-sm ${
                        currentView === "service"
                          ? "bg-emerald-50 text-emerald-800"
                          : "text-gray-600 hover:bg-gray-50 hover:text-emerald-800"
                      }`}
                    >
                      {s.shortTitle}
                    </button>
                  ))}

                  <div className="px-6 py-2">
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Clinical Procedures
                    </span>
                  </div>
                  {[SERVICES[9], SERVICES[10], SERVICES[11], SERVICES[12], SERVICES[13], SERVICES[15], SERVICES[16]].map((s) => (
                    <button
                      key={s.slug}
                      onClick={() => handleNavClick("service", s.slug)}
                      className={`w-full text-left pl-10 pr-6 py-2.5 text-sm ${
                        currentView === "service"
                          ? "bg-emerald-50 text-emerald-800"
                          : "text-gray-600 hover:bg-gray-50 hover:text-emerald-800"
                      }`}
                    >
                      {s.shortTitle}
                    </button>
                  ))}

                  <div className="px-6 py-2">
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Injections & Monitoring
                    </span>
                  </div>
                  {[SERVICES[6], SERVICES[14], SERVICES[7], SERVICES[8], SERVICES[17], SERVICES[18]].map((s) => (
                    <button
                      key={s.slug}
                      onClick={() => handleNavClick("service", s.slug)}
                      className={`w-full text-left pl-10 pr-6 py-2.5 text-sm ${
                        currentView === "service"
                          ? "bg-emerald-50 text-emerald-800"
                          : "text-gray-600 hover:bg-gray-50 hover:text-emerald-800"
                      }`}
                    >
                      {s.shortTitle}
                    </button>
                  ))}

                  <div className="my-2 mx-6 border-t border-border" />

                  {[
                    { label: "About Us", icon: Users, view: "home" },
                    { label: "Health Hub (Blog)", icon: BookOpen, view: "home" },
                    { label: "Contact Us", icon: Mail, view: "home" },
                  ].map((item) => (
                    <button
                      key={item.label}
                      onClick={() => handleNavClick(item.view)}
                      className="w-full text-left px-6 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-emerald-800 flex items-center gap-3"
                    >
                      <item.icon className="w-5 h-5 text-muted-foreground" />
                      {item.label}
                    </button>
                  ))}
                </div>

                {/* Mobile CTA */}
                <div className="p-4 border-t border-border bg-gray-50">
                  <a
                    href={`tel:${BUSINESS.phoneRaw}`}
                    onClick={() => {
                      trackPhoneCallClick();
                      setMobileOpen(false);
                    }}
                    className="flex items-center justify-center gap-2 w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-base font-semibold transition-colors"
                  >
                    <Phone className="w-5 h-5" />
                    Contact Our Expert
                  </a>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
