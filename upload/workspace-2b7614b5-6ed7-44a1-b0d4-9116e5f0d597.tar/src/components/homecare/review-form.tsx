"use client";

import { useState } from "react";
import { Star, Send, CheckCircle2 } from "lucide-react";
import { SERVICES } from "@/lib/seo-data";

export function ReviewForm() {
  const [name, setName] = useState("");
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [text, setText] = useState("");
  const [service, setService] = useState("");
  const [postToGoogle, setPostToGoogle] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim()) { setError("Please enter your name."); return; }
    if (rating === 0) { setError("Please select a rating."); return; }
    if (text.trim().length < 10) { setError("Please write at least 10 characters."); return; }

    setSubmitting(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, rating, text, service, postToGoogle }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong.");
      } else {
        setSubmitted(true);
      }
    } catch {
      setError("Network error. Please try again.");
    }
    setSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-xl border border-emerald-100 text-center">
        <div className="w-14 h-14 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-200">
          <CheckCircle2 className="w-7 h-7 text-white" />
        </div>
        <h3 className="text-xl font-extrabold text-emerald-900 mb-2">Thank You for Your Review!</h3>
        <p className="text-muted-foreground text-sm leading-relaxed">
          Your review has been submitted and will appear after approval.
          {postToGoogle && (
            <span className="block mt-2 font-semibold text-emerald-700">
              Your review will also be posted to our Google Business profile.
            </span>
          )}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-xl border border-gray-100">
      <h3 className="text-xl font-extrabold text-gray-900 mb-1">Write a Review</h3>
      <p className="text-sm text-muted-foreground mb-5">Share your experience with CareFirst Home Nursing Services.</p>

      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        {/* Name */}
        <div>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your Name"
            maxLength={50}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/80 focus:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 text-base transition-all"
          />
        </div>

        {/* Service */}
        <div>
          <select
            value={service}
            onChange={(e) => setService(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/80 focus:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 text-base transition-all appearance-none"
          >
            <option value="">Select Service (Optional)</option>
            {SERVICES.map((s) => (
              <option key={s.slug} value={s.shortTitle}>{s.shortTitle}</option>
            ))}
          </select>
        </div>

        {/* Star Rating */}
        <div>
          <p className="text-sm font-semibold text-gray-700 mb-2">Your Rating</p>
          <div className="flex gap-1.5">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                className="p-0.5 transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
                aria-label={`Rate ${star} star${star > 1 ? "s" : ""}`}
              >
                <Star
                  className={`w-8 h-8 transition-colors ${
                    star <= (hoverRating || rating)
                      ? "text-amber-500"
                      : "text-gray-200"
                  }`}
                  fill={star <= (hoverRating || rating) ? "#f59e0b" : "none"}
                />
              </button>
            ))}
            {rating > 0 && (
              <span className="text-sm text-muted-foreground self-center ml-2">
                {rating}/5
              </span>
            )}
          </div>
        </div>

        {/* Review Text */}
        <div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Tell us about your experience..."
            rows={3}
            maxLength={500}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/80 focus:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 text-base transition-all resize-none"
          />
          <p className="text-xs text-muted-foreground mt-1 text-right">{text.length}/500</p>
        </div>

        {/* Post to Google Checkbox */}
        <label className="flex items-start gap-2.5 text-sm text-muted-foreground cursor-pointer">
          <input
            type="checkbox"
            checked={postToGoogle}
            onChange={(e) => setPostToGoogle(e.target.checked)}
            className="mt-0.5 w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
          />
          <span>
            Also post this review to our{" "}
            <span className="font-semibold text-gray-700">Google Business Profile</span>
            . Your review will help others find us on Google.
          </span>
        </label>

        {error && (
          <p className="text-red-600 text-sm font-medium" role="alert">{error}</p>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg shadow-emerald-200 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Send className="w-4 h-4" />
          {submitting ? "Submitting..." : "Submit Review"}
        </button>
      </form>
    </div>
  );
}
