"use client";

import { BUSINESS, PROMO_CODE, trackWhatsAppClick } from "@/lib/seo-data";
import { LeadForm } from "./lead-form";
import { Shield, Clock, Award, Star, MessageCircle, Tag, Sparkles } from "lucide-react";

const TRUST_MICRO = [
  { Icon: Shield, text: "RN/ANM Certified" },
  { Icon: Clock, text: "24/7 Available" },
  { Icon: Award, text: "7+ Years Experience" },
  { Icon: Star, text: "4.8/5 Rating" },
];

interface HeroSectionProps {
  onPromoApply: (applied: boolean) => void;
  promoApplied: boolean;
}

export function HeroSection({ onPromoApply, promoApplied }: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden" aria-label="Hero">
      {/* Premium dark gradient */}
      <div className="absolute inset-0 hero-gradient" />

      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-400/8 rounded-full blur-[100px] -translate-y-1/3 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-teal-400/6 rounded-full blur-[80px] translate-y-1/3 -translate-x-1/4" />

      {/* Subtle pattern overlay */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left">
            {/* Promo Code Badge - Premium */}
            <div className="flex justify-center lg:justify-start mb-5">
              <div className="animate-promo-pulse inline-flex items-center gap-2.5 bg-gradient-to-r from-red-500 to-red-600 text-white px-5 py-2.5 rounded-full text-sm font-bold shadow-lg shadow-red-500/25 border border-red-400/30">
                <Sparkles className="w-4 h-4" />
                <span>50% OFF</span>
                <span className="bg-white/20 px-2 py-0.5 rounded-md text-xs tracking-widest font-black">{PROMO_CODE}</span>
              </div>
            </div>

            {/* Trust micro badges */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-2.5 mb-7">
              {TRUST_MICRO.map(({ Icon, text }) => (
                <span key={text} className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white/10 backdrop-blur-sm rounded-full text-white/80 text-sm font-medium border border-white/10">
                  <Icon className="w-3.5 h-3.5 text-emerald-300" />
                  {text}
                </span>
              ))}
            </div>

            {/* Main Heading */}
            <h1 className="text-3xl sm:text-4xl lg:text-[3.25rem] font-extrabold text-white leading-[1.1] mb-5">
              Trusted Nursing
              <span className="block bg-gradient-to-r from-emerald-300 to-teal-200 bg-clip-text text-transparent">Homecare in Hyderabad</span>
            </h1>

            {/* Description */}
            <p className="text-lg sm:text-xl text-white/75 max-w-xl mx-auto lg:mx-0 mb-6 leading-relaxed">
              Expert home nurses, ICU-trained staff, and specialized caregivers for all your medical needs at home. 100% background-verified &amp; RN/ANM certified caregivers delivering hospital-grade care.
            </p>

            {/* Pricing Teaser - Changes based on promo */}
            <div className="inline-flex flex-col items-center lg:items-start bg-white/8 backdrop-blur-md rounded-2xl px-7 py-5 mb-7 border border-white/12 shadow-xl">
              <p className="text-sm text-white/60 font-medium mb-2 tracking-wide uppercase">Starting Price for Home Nursing Services</p>
              {promoApplied ? (
                <div className="flex items-baseline gap-3">
                  <span className="text-xl text-white/40 line-through font-medium">₹1,998</span>
                  <span className="text-5xl font-black text-white tracking-tight">₹999<span className="text-2xl font-bold text-emerald-300">/-</span></span>
                </div>
              ) : (
                <div className="flex items-baseline gap-3">
                  <span className="text-5xl font-black text-white tracking-tight">₹1,998<span className="text-2xl font-bold text-white/60">/-</span></span>
                </div>
              )}
              {promoApplied && (
                <div className="flex items-center gap-2 mt-2">
                  <span className="inline-flex items-center gap-1 bg-red-500/30 text-red-300 px-2.5 py-0.5 rounded-md text-xs font-bold">
                    <Sparkles className="w-3 h-3" /> 50% OFF Applied
                  </span>
                </div>
              )}
              {!promoApplied && (
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-white/40">*Apply promo code {PROMO_CODE} in the form for 50% off</span>
                </div>
              )}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
              <a
                href={BUSINESS.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackWhatsAppClick()}
                className="inline-flex items-center gap-2.5 px-7 py-3.5 bg-[#25D366] hover:bg-[#1da851] text-white font-bold rounded-xl transition-all duration-300 shadow-lg shadow-green-500/25 hover:shadow-xl hover:shadow-green-500/30 hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:ring-offset-2 focus-visible:ring-offset-emerald-900"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp Us
              </a>
            </div>

            {/* NAP for SEO */}
            <div className="mt-8 text-white/35 text-sm" itemScope itemType="https://schema.org/Organization">
              <span itemProp="name" className="font-medium text-white/50">{BUSINESS.name}</span>
              <span itemProp="address" itemScope itemType="https://schema.org/PostalAddress"> — <span itemProp="streetAddress">{BUSINESS.address.streetAddress}</span>, <span itemProp="addressLocality">{BUSINESS.address.addressLocality}</span>, <span itemProp="addressRegion">{BUSINESS.address.addressRegion}</span> <span itemProp="postalCode">{BUSINESS.address.postalCode}</span></span>
            </div>
          </div>

          {/* Lead Form - Premium card */}
          <div className="max-w-md mx-auto lg:max-w-none w-full">
            <LeadForm variant="hero" onPromoApply={onPromoApply} />
          </div>
        </div>
      </div>
    </section>
  );
}
