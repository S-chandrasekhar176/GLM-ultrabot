"use client";

import { Phone, MessageCircle } from "lucide-react";
import { BUSINESS, trackWhatsAppClick, trackPhoneCallClick } from "@/lib/seo-data";

export function MobileBottomBar() {
  return (
    <div className="mobile-bottom-bar lg:hidden" role="complementary" aria-label="Quick contact">
      <a
        href={`tel:${BUSINESS.phoneRaw}`}
        onClick={() => trackPhoneCallClick()}
        className="call-btn"
        aria-label="Call CareFirst now"
      >
        <Phone className="w-5 h-5" />
        <span>Call Now</span>
      </a>
      <a
        href={BUSINESS.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackWhatsAppClick()}
        className="whatsapp-btn"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle className="w-5 h-5" />
        <span>WhatsApp</span>
      </a>
    </div>
  );
}
