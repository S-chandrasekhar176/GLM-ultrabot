import { BUSINESS, SERVICES } from "@/lib/seo-data";
import { Heart, MapPin, Phone, Mail, BadgeCheck, ShieldCheck, Lock, MessageCircle } from "lucide-react";

const TRUST_FOOTER = [
  { Icon: BadgeCheck, label: "RN/ANM Certified Nurses" },
  { Icon: ShieldCheck, label: "Telangana Nurses Council Registered" },
  { Icon: Lock, label: "Data Secure & DPDP Compliant" },
];

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 pb-mobile-bar" aria-label="Site footer">
      {/* Trust Badges Bar - Premium */}
      <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap justify-center gap-6">
          {TRUST_FOOTER.map(({ Icon, label }) => (
            <div key={label} className="trust-badge flex items-center gap-2 text-emerald-100 text-sm font-medium">
              <Icon className="w-5 h-5" />
              {label}
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand & NAP */}
          <div>
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-900/50">
                <Heart className="w-5 h-5 text-white" fill="white" />
              </div>
              <div>
                <span className="block text-lg font-extrabold text-white leading-tight">CareFirst</span>
                <span className="block text-xs text-gray-500 leading-tight">Home Nursing Services</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-5 leading-relaxed">
              Trusted home nursing services in Hyderabad since 2018. Background-verified, certified staff delivering compassionate medical care at your doorstep.
            </p>
            <div className="space-y-2.5 text-sm">
              <div className="flex items-start gap-2.5"><MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" /><span>{BUSINESS.address.streetAddress}, {BUSINESS.address.addressLocality}, {BUSINESS.address.addressRegion} {BUSINESS.address.postalCode}</span></div>
              <div className="flex items-center gap-2.5"><Phone className="w-4 h-4 flex-shrink-0 text-emerald-400" /><a href={`tel:${BUSINESS.phoneRaw}`} className="hover:text-white transition-colors">{BUSINESS.phone}</a></div>
              <div className="flex items-center gap-2.5"><Mail className="w-4 h-4 flex-shrink-0 text-emerald-400" /><a href={`mailto:${BUSINESS.email}`} className="hover:text-white transition-colors">{BUSINESS.email}</a></div>
            </div>
          </div>

          {/* Services Links */}
          <div>
            <h3 className="text-white font-bold mb-5 text-base">Our Services</h3>
            <ul className="space-y-2.5">
              {SERVICES.map((s) => (
                <li key={s.slug}><span className="text-sm text-gray-400 hover:text-emerald-300 transition-colors cursor-pointer">{s.title}</span></li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold mb-5 text-base">Quick Links</h3>
            <ul className="space-y-2.5 text-sm">
              {["About Us", "Health Hub (Blog)", "Careers", "Privacy Policy", "Terms of Service", "DPDP Compliance"].map((link) => (
                <li key={link}><span className="text-gray-400 hover:text-emerald-300 transition-colors cursor-pointer">{link}</span></li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h3 className="text-white font-bold mb-5 text-base">Service Areas</h3>
            <ul className="space-y-2.5 text-sm">
              {["Jubilee Hills", "Banjara Hills", "Madhapur", "Kukatpally", "Gachibowli", "HITEC City", "Kondapur", "Miyapur", "Secunderabad", "Ameerpet"].map((area) => (
                <li key={area}><span className="text-gray-400 hover:text-emerald-300 transition-colors cursor-pointer">{area}</span></li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} {BUSINESS.name}. All rights reserved.
          </p>
          <a
            href={BUSINESS.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-xl text-sm font-bold transition-all duration-300 shadow-md shadow-green-900/30"
          >
            <MessageCircle className="w-4 h-4" />
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </footer>
  );
}
