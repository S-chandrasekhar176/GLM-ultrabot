"use client";

import { SERVICES, BUSINESS, PROMO_CODE, getFAQSchema, getServiceSchema, trackWhatsAppClick, trackPhoneCallClick } from "@/lib/seo-data";
import { LeadForm } from "./lead-form";
import { Phone, MessageCircle, ArrowLeft, Clock, ShieldCheck, Tag, Sparkles } from "lucide-react";

interface ServicePageProps {
  serviceSlug: string;
  onBack: () => void;
  promoApplied: boolean;
  onPromoApply?: (applied: boolean) => void;
}

export function ServicePageTemplate({ serviceSlug, onBack, promoApplied, onPromoApply }: ServicePageProps) {
  const service = SERVICES.find((s) => s.slug === serviceSlug);
  if (!service) return <div>Service not found</div>;

  const faqSchema = getFAQSchema(service.faqs);
  const serviceSchema = getServiceSchema(service);

  return (
    <main>
      {/* Inject FAQ + Service JSON-LD */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />

      {/* Breadcrumb */}
      <nav className="bg-gray-50 border-b border-gray-100" aria-label="Breadcrumb">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <ol className="flex items-center gap-2 text-sm text-muted-foreground">
            <li><button onClick={onBack} className="hover:text-emerald-700 transition-colors font-medium">Home</button></li>
            <li className="text-gray-300">/</li>
            <li><button onClick={onBack} className="hover:text-emerald-700 transition-colors font-medium">Services</button></li>
            <li className="text-gray-300">/</li>
            <li className="text-emerald-800 font-bold">{service.title}</li>
          </ol>
        </div>
      </nav>

      {/* Service Hero - Premium gradient */}
      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 text-white py-14 sm:py-20">
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button onClick={onBack} className="inline-flex items-center gap-1.5 text-emerald-300 hover:text-white mb-6 text-sm font-semibold transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to All Services
          </button>
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold mb-5 leading-tight">{service.title} in Hyderabad</h1>
              <p className="text-emerald-100/80 text-lg leading-relaxed mb-8">{service.description}</p>
              <div className="flex flex-wrap gap-3">
                <a href={BUSINESS.whatsappUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackWhatsAppClick()} className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#25D366] hover:bg-[#1da851] rounded-xl font-bold transition-all duration-300 shadow-lg shadow-green-500/25">
                  <MessageCircle className="w-5 h-5" /> WhatsApp Us
                </a>
                <a href={`tel:${BUSINESS.phoneRaw}`} onClick={() => trackPhoneCallClick()} className="inline-flex items-center gap-2 px-6 py-3.5 border-2 border-white/30 hover:border-white/60 rounded-xl font-bold transition-all duration-300">
                  <Phone className="w-5 h-5" /> Call Now
                </a>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="w-full aspect-[4/3] bg-white/5 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/10">
                <div className="text-center text-emerald-300/50">
                  <ShieldCheck className="w-16 h-16 mx-auto mb-2" />
                  <p className="text-sm font-medium">Service Image</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works & Pricing - Premium */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">Simple Process</span>
            <h2 className="text-2xl font-extrabold text-gray-900 mb-4">How It Works</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {[
              { step: "1", title: "Share Requirements", desc: "Tell us your care needs and medical requirements via phone, WhatsApp, or our form." },
              { step: "2", title: "Care Plan", desc: "A personalized care plan is created in consultation with your treating doctor." },
              { step: "3", title: "Nurse Matching", desc: "We assign the most suitable background-verified nurse based on expertise." },
              { step: "4", title: "Care Begins", desc: "Your dedicated nurse arrives at home ready to provide expert care." },
            ].map((item) => (
              <div key={item.step} className="premium-card text-center p-6">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-emerald-700 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-black text-lg shadow-md shadow-emerald-200">{item.step}</div>
                <h3 className="font-bold text-gray-900 mb-1.5">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Pricing Card - Premium */}
          <div className="max-w-lg mx-auto bg-white rounded-2xl p-8 sm:p-10 text-center shadow-xl border border-emerald-100">
            {promoApplied ? (
              <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-1.5 rounded-full text-sm font-bold mb-4 shadow-sm shadow-red-200">{service.discount} — Limited Time Offer</span>
            ) : (
              <span className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 px-4 py-1.5 rounded-full text-sm font-bold mb-4">Standard Pricing</span>
            )}
            <p className="text-sm text-emerald-700 font-semibold mb-2">Starting Price for {service.title}</p>
            <div className="flex items-center justify-center gap-4 mb-3">
              {promoApplied && (
                <span className="text-2xl text-gray-400 line-through font-medium">{service.originalCost}</span>
              )}
              <span className={`text-5xl font-black tracking-tight ${promoApplied ? "text-gray-900" : "text-gray-900"}`}>{promoApplied ? service.baselineCost : service.originalCost}<span className={`text-2xl font-bold ${promoApplied ? "text-emerald-600" : "text-gray-500"}`}>/-</span></span>
            </div>
            <p className="text-sm text-muted-foreground mb-5">Actual cost depends on medical complexity. Contact us for a customized quote.</p>
            {/* Promo Code Display */}
            <div className="inline-flex items-center gap-2.5 bg-gradient-to-r from-red-50 to-rose-50 rounded-xl border border-red-200 px-5 py-2.5">
              <Sparkles className="w-4 h-4 text-red-500" />
              <span className="text-sm font-semibold text-gray-700">Promo:</span>
              <span className="text-sm font-black text-red-600 tracking-[0.15em] bg-white px-2.5 py-0.5 rounded shadow-sm">{PROMO_CODE}</span>
              <span className="text-xs font-bold text-red-600">= 50% OFF</span>
            </div>
          </div>
        </div>
      </section>

      {/* Lead Form Inline */}
      <section className="py-16 bg-gray-50/80">
        <div className="max-w-lg mx-auto px-4 sm:px-6 lg:px-8">
          <LeadForm variant="inline" onPromoApply={onPromoApply} />
        </div>
      </section>

      {/* FAQ Section - Premium */}
      <section className="py-16 sm:py-20" aria-label="Frequently asked questions">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">FAQs</span>
            <h2 className="text-2xl font-extrabold text-gray-900 mb-4">
              Frequently Asked Questions About {service.shortTitle} in Hyderabad
            </h2>
          </div>
          <div className="space-y-3">
            {service.faqs.map((faq, idx) => (
              <details key={idx} className="faq-item premium-card rounded-xl group">
                <summary className="flex items-center p-5 font-semibold text-gray-900 hover:text-emerald-800 transition-colors">
                  {faq.question}
                </summary>
                <div className="px-5 pb-5 text-muted-foreground leading-relaxed border-t border-gray-50 pt-4">
                  {faq.answer}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA - Premium */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900" />
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-2xl font-extrabold mb-3">Need {service.shortTitle} in Hyderabad?</h2>
          <p className="text-emerald-200/80 text-lg mb-8">Speak with our care coordinator today. No obligation.</p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a href={`tel:${BUSINESS.phoneRaw}`} onClick={() => trackPhoneCallClick()} className="inline-flex items-center gap-2 px-7 py-3.5 bg-white text-emerald-900 font-bold rounded-xl hover:bg-gray-50 transition-all duration-300 shadow-xl">
              <Phone className="w-5 h-5" /> Speak with Our Expert
            </a>
            <a href={BUSINESS.whatsappUrl} target="_blank" rel="noopener noreferrer" onClick={() => trackWhatsAppClick()} className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#25D366] hover:bg-[#1da851] rounded-xl font-bold transition-all duration-300 shadow-lg shadow-green-500/25">
              <MessageCircle className="w-5 h-5" /> WhatsApp Now
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
