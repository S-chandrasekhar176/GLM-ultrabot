"use client";

import { CheckCircle2, XCircle, Trophy } from "lucide-react";

const COMPARISON_DATA = [
  {
    feature: "Nurse Certification",
    carefirst: "RN/ANM Certified Nurses",
    others: "Unverified or minimal training",
  },
  {
    feature: "Response Time",
    carefirst: "15 mins to 1 hour response",
    others: "24-48 hours or more",
  },
  {
    feature: "Care Coordinator",
    carefirst: "Dedicated single point of contact",
    others: "No assigned coordinator",
  },
  {
    feature: "Pricing Transparency",
    carefirst: "Upfront cost, no hidden charges",
    others: "Hidden charges common",
  },
  {
    feature: "Service Areas",
    carefirst: "Pan-Hyderabad coverage",
    others: "Limited areas only",
  },
];

export function ComparisonSection() {
  return (
    <section className="py-20 sm:py-24 bg-white" aria-label="Comparison with others">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <span className="inline-block px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold tracking-wide uppercase mb-4 border border-emerald-100">
            Honest Comparison
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-4">
            Others vs CareFirst — See the Difference
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Not all home nursing services are the same. Here is an honest comparison of what you get with CareFirst versus typical providers in Hyderabad.
          </p>
        </div>

        {/* Comparison Table - Premium */}
        <div className="rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          {/* Table Header */}
          <div className="grid grid-cols-3">
            <div className="p-5 font-bold text-gray-700 text-sm sm:text-base bg-gray-50 border-b border-gray-200">
              Feature
            </div>
            <div className="p-5 font-bold text-white text-sm sm:text-base text-center border-l border-white/20 bg-gradient-to-r from-emerald-700 to-emerald-600">
              <div className="flex items-center justify-center gap-1.5">
                <Trophy className="w-4 h-4 text-amber-300" />
                CareFirst
              </div>
            </div>
            <div className="p-5 font-bold text-gray-500 text-sm sm:text-base text-center border-l border-gray-200 bg-gray-50">
              Others
            </div>
          </div>

          {/* Table Rows */}
          {COMPARISON_DATA.map((row, idx) => (
            <div
              key={row.feature}
              className={`grid grid-cols-3 border-b border-gray-100 last:border-b-0 comparison-table-row ${
                idx % 2 === 0 ? "bg-white" : "bg-gray-50/60"
              }`}
            >
              <div className="p-4 sm:p-5 font-semibold text-gray-900 text-sm sm:text-base flex items-center">
                {row.feature}
              </div>
              <div className="p-4 sm:p-5 border-l border-gray-100 text-center flex flex-col items-center justify-center gap-1.5 bg-emerald-50/30">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span className="text-xs sm:text-sm text-emerald-700 font-semibold leading-tight">
                  {row.carefirst}
                </span>
              </div>
              <div className="p-4 sm:p-5 border-l border-gray-100 text-center flex flex-col items-center justify-center gap-1.5">
                <XCircle className="w-5 h-5 text-red-300" />
                <span className="text-xs sm:text-sm text-gray-400 leading-tight">
                  {row.others}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-10 bg-gradient-to-r from-emerald-800 to-emerald-900 rounded-2xl p-8 sm:p-10 text-center text-white shadow-xl shadow-emerald-900/20">
          <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-7 h-7 text-amber-300" />
          </div>
          <p className="text-xl sm:text-2xl font-extrabold mb-3">
            Choose the Trusted Name in Home Nursing
          </p>
          <p className="text-emerald-200 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            With 1,200+ families served, 350+ verified nurses, and a 4.8/5 Google rating, CareFirst is Hyderabad&apos;s most trusted home nursing service. Book your care today.
          </p>
        </div>
      </div>
    </section>
  );
}
