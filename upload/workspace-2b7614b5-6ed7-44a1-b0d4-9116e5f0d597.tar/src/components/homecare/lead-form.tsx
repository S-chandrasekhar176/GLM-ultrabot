"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  BUSINESS,
  SERVICES,
  PROMO_CODE,
  trackPhoneCallClick,
  trackFormSubmission,
} from "@/lib/seo-data";
import { Phone, CheckCircle2, Tag, Sparkles, X } from "lucide-react";

export function LeadForm({ variant = "hero", page = "home", onPromoApply }: { variant?: "hero" | "inline"; page?: string; onPromoApply?: (applied: boolean) => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [careType, setCareType] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState("");
  const [dpdpConsent, setDpdpConsent] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === PROMO_CODE) {
      setPromoApplied(true);
      setPromoError("");
      onPromoApply?.(true);
    } else {
      setPromoApplied(false);
      setPromoError("Invalid promo code");
      onPromoApply?.(false);
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = "Please enter your name.";
    if (!phone.trim()) newErrors.phone = "Please enter your phone number.";
    else if (!/^[6-9]\d{9}$/.test(phone.replace(/\D/g, "")))
      newErrors.phone = "Please enter a valid 10-digit Indian mobile number.";
    if (!careType) newErrors.careType = "Please select the type of care needed.";
    if (!dpdpConsent)
      newErrors.dpdpConsent = "Please accept the data consent to proceed.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    trackFormSubmission({ name, phone, careType });
    setSubmitting(true);
    try {
      await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, careType, page, promoCode: promoApplied ? promoCode.toUpperCase() : "" }),
      });
    } catch (err) {
      console.error("Lead API error:", err);
    }
    setSubmitting(false);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setName("");
      setPhone("");
      setCareType("");
      setPromoCode("");
      setPromoApplied(false);
      setPromoError("");
      setDpdpConsent(false);
    }, 5000);
  };

  if (submitted) {
    return (
      <div className="bg-white rounded-2xl p-7 sm:p-9 shadow-2xl border border-emerald-100 text-center">
        <div className="w-16 h-16 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-200">
          <CheckCircle2 className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-extrabold text-emerald-900 mb-2">
          Thank You! We&apos;ll Call You Shortly
        </h3>
        <p className="text-muted-foreground mb-3">
          Our care coordinator will reach out within 15 minutes during business hours.
        </p>
        {promoApplied && (
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 rounded-full text-sm font-bold">
            <Sparkles className="w-4 h-4" />
            Promo {PROMO_CODE} Applied — 50% OFF on first booking!
          </div>
        )}
      </div>
    );
  }

  const isHero = variant === "hero";

  return (
    <div
      className={`rounded-2xl shadow-2xl ${
        isHero
          ? "bg-white/[0.97] backdrop-blur-xl border border-white/20 p-6 sm:p-8"
          : "bg-white border border-gray-100 p-6 shadow-xl"
      }`}
    >
      <h3
        className={`font-extrabold mb-1 ${
          isHero ? "text-2xl text-emerald-900" : "text-xl text-emerald-900"
        }`}
      >
        Book Home Nursing Care
      </h3>
      <p
        className={`text-sm mb-5 ${
          isHero ? "text-gray-500" : "text-muted-foreground"
        }`}
      >
        Get expert care advice within 15 minutes.
      </p>

      {/* Promo Code Banner - Very Visible */}
      <div className="relative bg-gradient-to-r from-red-500 via-red-600 to-rose-600 rounded-xl px-4 py-3 mb-5 overflow-hidden shadow-md shadow-red-200">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />
        <div className="relative flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-white">
            <Sparkles className="w-4 h-4" />
            <span className="font-bold text-sm">Flat 50% OFF</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-white/70 text-xs">Code:</span>
            <span className="bg-white/20 text-white px-2.5 py-0.5 rounded-md text-sm font-black tracking-widest">{PROMO_CODE}</span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-3.5">
        {/* Name */}
        <div>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your Full Name"
            autoComplete="name"
            aria-label="Your full name"
            className="w-full px-4 py-3.5 rounded-xl border text-base transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 border-gray-200 bg-gray-50/80 focus:bg-white focus:shadow-sm"
          />
          {errors.name && (
            <p className="text-red-600 text-sm mt-1" role="alert">
              {errors.name}
            </p>
          )}
        </div>

        {/* Phone */}
        <div>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">+91</span>
            <input
              type="tel"
              value={phone}
              onChange={(e) =>
                setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))
              }
              placeholder="98XXXXXXXX"
              autoComplete="tel"
              aria-label="Your phone number"
              maxLength={10}
              className="w-full pl-14 pr-4 py-3.5 rounded-xl border text-base transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 border-gray-200 bg-gray-50/80 focus:bg-white focus:shadow-sm"
            />
          </div>
          {errors.phone && (
            <p className="text-red-600 text-sm mt-1" role="alert">
              {errors.phone}
            </p>
          )}
        </div>

        {/* Care Type */}
        <div>
          <select
            value={careType}
            onChange={(e) => setCareType(e.target.value)}
            aria-label="Type of care required"
            className="w-full px-4 py-3.5 rounded-xl border text-base transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:border-emerald-400 border-gray-200 bg-gray-50/80 focus:bg-white appearance-none"
          >
            <option value="">Select Care Required</option>
            {SERVICES.map((s) => (
              <option key={s.slug} value={s.slug}>
                {s.title}
              </option>
            ))}
            <option value="other">Other / Not Sure</option>
          </select>
          {errors.careType && (
            <p className="text-red-600 text-sm mt-1" role="alert">
              {errors.careType}
            </p>
          )}
        </div>

        {/* Promo Code Input */}
        <div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Tag className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={promoCode}
                onChange={(e) => {
                  setPromoCode(e.target.value.toUpperCase());
                  if (promoApplied) {
                    setPromoApplied(false);
                    onPromoApply?.(false);
                  }
                  if (promoError) setPromoError("");
                }}
                placeholder="Enter Promo Code"
                aria-label="Promo code"
                maxLength={10}
                className={`w-full pl-10 pr-4 py-3.5 rounded-xl border text-base font-medium tracking-wide transition-all duration-200 focus:outline-none focus-visible:ring-2 bg-gray-50/80 focus:bg-white ${
                  promoApplied
                    ? "border-emerald-500 bg-emerald-50/80 focus-visible:ring-emerald-500 focus-visible:border-emerald-400"
                    : promoError
                    ? "border-red-400 focus-visible:ring-red-400"
                    : "border-gray-200 focus-visible:ring-emerald-500 focus-visible:border-emerald-400"
                }`}
              />
              {promoApplied && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={handleApplyPromo}
              disabled={promoApplied}
              className={`px-5 py-3.5 rounded-xl font-bold text-sm transition-all duration-200 whitespace-nowrap ${
                promoApplied
                  ? "bg-emerald-600 text-white cursor-default shadow-sm shadow-emerald-200"
                  : "bg-gray-900 text-white hover:bg-gray-800 active:scale-[0.97] shadow-sm"
              }`}
            >
              {promoApplied ? "Applied" : "Apply"}
            </button>
          </div>
          {promoApplied && (
            <p className="text-emerald-700 text-sm mt-1.5 font-semibold flex items-center gap-1" role="status">
              <CheckCircle2 className="w-3.5 h-3.5" />
              50% discount applied on your first booking!
            </p>
          )}
          {promoError && (
            <p className="text-red-600 text-sm mt-1.5 font-medium" role="alert">
              {promoError}
            </p>
          )}
        </div>

        {/* Primary CTA */}
        <Button
          type="submit"
          className={`w-full py-4 text-base font-bold rounded-xl shadow-lg transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] ${
            promoApplied
              ? "bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-emerald-300"
              : "bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-200"
          }`}
        >
          {submitting
            ? "Submitting..."
            : promoApplied
            ? "Book Now with 50% OFF"
            : "Book Home Nursing Care"}
        </Button>

        {/* Urgent CTA */}
        <a
          href={`tel:${BUSINESS.phoneRaw}`}
          onClick={() => trackPhoneCallClick()}
          className="flex items-center justify-center gap-2 w-full py-3.5 rounded-xl border-2 border-red-500/80 text-red-600 font-bold hover:bg-red-50 transition-all duration-200 text-base active:scale-[0.98]"
        >
          <Phone className="w-4 h-4" />
          Call Now for Immediate Care
        </a>

        {/* DPDP Consent */}
        <div className="pt-1">
          <label
            className={`flex items-start gap-2.5 text-sm cursor-pointer ${
              errors.dpdpConsent ? "text-red-600" : "text-muted-foreground"
            }`}
          >
            <input
              type="checkbox"
              checked={dpdpConsent}
              onChange={(e) => setDpdpConsent(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
            />
            <span>
              I authorize {BUSINESS.name} to contact me. My data is
              secure, confidential, and handled in compliance with the DPDP
              Act, 2023.
            </span>
          </label>
          {errors.dpdpConsent && (
            <p className="text-red-600 text-sm mt-1 ml-6" role="alert">
              {errors.dpdpConsent}
            </p>
          )}
        </div>
      </form>
    </div>
  );
}
